(function () {
  'use strict';

  
  let console;

  (function () {
    const preMessage = 'Ambient light for YouTube™ |';

    const enrich = (...args) => {
      if (args.length <= 0) return args;

      if (typeof args[0] === 'string') {
        const [firstArg, ...postArgs] = args;
        return [`${preMessage} ${firstArg}`, ...postArgs];
      }

      return [preMessage, ...args];
    };

    console = {
      log: (...args) => globalThis.console.log(...enrich(...args)),
      debug: (...args) => globalThis.console.debug(...enrich(...args)),
      warn: (...args) => globalThis.console.warn(...enrich(...args)),
      error: (...args) => globalThis.console.error(...enrich(...args)),
      dir: (...args) => globalThis.console.dir(...args),
    };
  })();


  const PARAMS = `struct Params { origin: vec2<i32>, full: vec2<u32>, tile: vec2<u32>, spare: vec2<u32> };`;
  const THREADS = 64;
  const HALO = 3;
  function validateModel(model) {
    var _model$layers;
    const shapes = [[5, 1, 32], [1, 32, 5], [3, 5, 5], [1, 5, 32], [1, 32, (model === null || model === void 0 ? void 0 : model.scale) ** 2]];
    if ((model === null || model === void 0 ? void 0 : model.schemaVersion) !== 1 || ![2, 3].includes(model.scale) || model.halo !== HALO || ((_model$layers = model.layers) === null || _model$layers === void 0 ? void 0 : _model$layers.length) !== 5 || !Number.isFinite(model.outputBias)) {
      throw new Error('Unsupported FSRCNN-small model');
    }
    for (let i = 0; i < shapes.length; i++) {
      var _layer$weights, _layer$bias, _layer$alpha;
      const layer = model.layers[i],
        [kernel, input, output] = shapes[i];
      if (layer.kernelSize !== kernel || layer.inChannels !== input || layer.outChannels !== output || ((_layer$weights = layer.weights) === null || _layer$weights === void 0 ? void 0 : _layer$weights.length) !== kernel * kernel * input * output || i < 4 && (((_layer$bias = layer.bias) === null || _layer$bias === void 0 ? void 0 : _layer$bias.length) !== output || ((_layer$alpha = layer.alpha) === null || _layer$alpha === void 0 ? void 0 : _layer$alpha.length) !== output) || i === 4 && (layer.bias != null || layer.alpha != null) || ![...layer.weights, ...(layer.bias || []), ...(layer.alpha || [])].every(Number.isFinite)) {
        throw new Error(`Invalid FSRCNN-small layer ${i}`);
      }
    }
  }
  function packParameters(layer) {
    const padded = Math.ceil(layer.outChannels / 4) * 4;
    const inputs = layer.kernelSize * layer.kernelSize * layer.inChannels;
    const data = new Float32Array((inputs + (layer.bias ? 1 : 0) + (layer.alpha ? 1 : 0)) * padded);
    for (let input = 0; input < inputs; input++) {
      for (let output = 0; output < layer.outChannels; output++) {
        data[input * padded + output] = layer.weights[input * layer.outChannels + output];
      }
    }
    if (layer.bias) data.set(layer.bias, inputs * padded);
    if (layer.alpha) data.set(layer.alpha, (inputs + 1) * padded);
    return data;
  }
  function convolutionShader(layer, final) {
    const {
      kernelSize: k,
      inChannels: input,
      outChannels: output
    } = layer;
    const groups = Math.ceil(output / 4),
      count = k * k * input * groups;
    return `${PARAMS}
@group(0) @binding(0) var<storage, read> source: array<f32>;
@group(0) @binding(1) var<storage, read_write> destination: array<f32>;
@group(0) @binding(2) var<storage, read> learned: array<vec4<f32>>;
@group(0) @binding(3) var<uniform> p: Params;
@compute @workgroup_size(${THREADS}) fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  let n = gid.x;
  if (n >= p.tile.x * p.tile.y * ${groups}u) { return; }
  let group = n % ${groups}u;
  let pixel = n / ${groups}u;
  let xy = vec2<i32>(i32(pixel % p.tile.x), i32(pixel / p.tile.x));
  let global = p.origin + xy;
  // Zero at the REAL frame edge at every layer, including after bias/PReLU.
  if (any(global < vec2<i32>(0)) || any(global >= vec2<i32>(p.full))) {
    for (var lane = 0u; lane < 4u; lane++) {
      if (group * 4u + lane < ${output}u) { destination[pixel * ${output}u + group * 4u + lane] = 0.0; }
    }
    return;
  }
  var sum = ${final ? 'vec4<f32>(0.0)' : `learned[${count}u + group]`};
  for (var ky = 0; ky < ${k}; ky++) {
    for (var kx = 0; kx < ${k}; kx++) {
      let at = xy + vec2<i32>(kx - ${Math.floor(k / 2)}, ky - ${Math.floor(k / 2)});
      if (all(at >= vec2<i32>(0)) && all(at < vec2<i32>(p.tile))) {
        let base = (u32(at.y) * p.tile.x + u32(at.x)) * ${input}u;
        for (var c = 0u; c < ${input}u; c++) {
          let weight = ((u32(ky * ${k} + kx) * ${input}u + c) * ${groups}u) + group;
          sum += source[base + c] * learned[weight];
        }
      }
    }
  }
  let value = ${final ? 'sum' : `max(vec4<f32>(0.0), sum) + learned[${count + groups}u + group] * min(vec4<f32>(0.0), sum)`};
  for (var lane = 0u; lane < 4u; lane++) {
    if (group * 4u + lane < ${output}u) { destination[pixel * ${output}u + group * 4u + lane] = value[lane]; }
  }
}`;
  }
  const INITIALIZE = `${PARAMS}
@group(0) @binding(0) var image: texture_2d<f32>;
@group(0) @binding(1) var<storage, read_write> destination: array<f32>;
@group(0) @binding(2) var<uniform> p: Params;
@compute @workgroup_size(${THREADS}) fn main(@builtin(global_invocation_id) gid: vec3<u32>) {
  if (gid.x >= p.tile.x * p.tile.y) { return; }
  let pos = p.origin + vec2<i32>(i32(gid.x % p.tile.x), i32(gid.x / p.tile.x));
  var value = 0.0;
  if (all(pos >= vec2<i32>(0)) && all(pos < vec2<i32>(p.full))) {
    value = dot(textureLoad(image, pos, 0).rgb, vec3<f32>(0.299, 0.587, 0.114));
  }
  destination[gid.x] = value;
}`;
  function outputShader(scale, outputBias) {
    return `${PARAMS}
@group(0) @binding(0) var image: texture_2d<f32>;
@group(0) @binding(1) var filtering: sampler;
@group(0) @binding(2) var<storage, read> predicted: array<f32>;
@group(0) @binding(3) var<uniform> p: Params;
@vertex fn vertex(@builtin(vertex_index) i: u32) -> @builtin(position) vec4<f32> {
  let xy = array<vec2<f32>, 3>(vec2<f32>(-1,-1),vec2<f32>(3,-1),vec2<f32>(-1,3));
  return vec4<f32>(xy[i], 0, 1);
}
@fragment fn fragment(@builtin(position) position: vec4<f32>) -> @location(0) vec4<f32> {
  let out = vec2<u32>(position.xy);
  let low = vec2<i32>(out / ${scale}u) - p.origin;
  let channel = (out.y % ${scale}u) * ${scale}u + out.x % ${scale}u;
  let luminance = clamp(predicted[(u32(low.y) * p.tile.x + u32(low.x)) * ${scale * scale}u + channel] + f32(${outputBias}), 0.0, 1.0);
  let rgb = textureSampleLevel(image, filtering, position.xy / (vec2<f32>(p.full) * ${scale}.0), 0.0).rgb;
  let delta = luminance - dot(rgb, vec3<f32>(0.299, 0.587, 0.114));
  return vec4<f32>(clamp(rgb + vec3<f32>(delta), vec3<f32>(0), vec3<f32>(1)), 1);
}`;
  }
  async function createWebGpuUpscaler({
    canvas,
    model,
    tileSize = 256,
    device: suppliedDevice
  } = {}) {
    var _adapter$info, _adapter$info2, _adapter$info3;
    validateModel(model);
    if (!(canvas !== null && canvas !== void 0 && canvas.getContext) || !Number.isInteger(tileSize) || tileSize < 1) throw new Error('Invalid AI canvas or tile size');
    const {
      GPUBufferUsage: BU,
      GPUTextureUsage: TU
    } = globalThis;
    if (!navigator.gpu || !BU) throw new Error('WebGPU is unavailable');
    const adapter = suppliedDevice ? null : await navigator.gpu.requestAdapter({
      powerPreference: 'high-performance'
    });
    if (!suppliedDevice && !adapter) throw new Error('No WebGPU adapter is available');
    const device = suppliedDevice || (await adapter.requestDevice());
    const context = canvas.getContext('webgpu');
    if (!context) {
      if (!suppliedDevice) device.destroy();
      throw new Error('WebGPU canvas is unavailable');
    }
    const format = navigator.gpu.getPreferredCanvasFormat();
    const gpuInfo = {
      isFallbackAdapter: (adapter === null || adapter === void 0 ? void 0 : adapter.isFallbackAdapter) === true || (adapter === null || adapter === void 0 ? void 0 : (_adapter$info = adapter.info) === null || _adapter$info === void 0 ? void 0 : _adapter$info.isFallbackAdapter) === true,
      vendor: (adapter === null || adapter === void 0 ? void 0 : (_adapter$info2 = adapter.info) === null || _adapter$info2 === void 0 ? void 0 : _adapter$info2.vendor) || '',
      description: (adapter === null || adapter === void 0 ? void 0 : (_adapter$info3 = adapter.info) === null || _adapter$info3 === void 0 ? void 0 : _adapter$info3.description) || ''
    };
    const resources = new Set();
    let frame = null,
      destroyed = false,
      busy = false,
      fatal = null;
    const own = resource => {
      resources.add(resource);
      return resource;
    };
    const release = resource => {
      resources.delete(resource);
      resource.destroy();
    };
    const buffer = (size, usage, data) => {
      const result = own(device.createBuffer({
        size: Math.max(4, size),
        usage,
        mappedAtCreation: !!data
      }));
      if (data) {
        new Uint8Array(result.getMappedRange()).set(new Uint8Array(data.buffer, data.byteOffset, data.byteLength));
        result.unmap();
      }
      return result;
    };
    const check = () => {
      if (destroyed) throw new Error('AI renderer has been destroyed');
      if (fatal) throw fatal;
    };
    const disposeFrame = () => {
      if (!frame) return;
      for (const resource of frame.resources) release(resource);
      frame = null;
    };
    const fail = error => {
      if (fatal || destroyed) return;
      fatal = error instanceof Error ? error : new Error(String(error));
      for (const resource of resources) resource.destroy();
      resources.clear();
      frame = null;
      context.unconfigure();
      if (!suppliedDevice) device.destroy();
    };
    const uncaptured = event => fail(new Error(`WebGPU: ${event.error.message}`));
    device.addEventListener('uncapturederror', uncaptured);
    device.lost.then(info => {
      if (!destroyed) fail(new Error(`WebGPU device lost: ${info.message || info.reason}`));
    });
    const destroy = () => {
      if (destroyed) return;
      destroyed = true;
      device.removeEventListener('uncapturederror', uncaptured);
      context.unconfigure();
      for (const resource of resources) resource.destroy();
      resources.clear();
      frame = null;
      if (!suppliedDevice) device.destroy();
    };
    try {
      tileSize = Math.min(tileSize, 256);
      while ((tileSize + 2 * HALO) ** 2 * 32 * 4 > device.limits.maxStorageBufferBindingSize || Math.ceil((tileSize + 2 * HALO) ** 2 * 32 / THREADS) > device.limits.maxComputeWorkgroupsPerDimension) tileSize--;
      if (tileSize < 1) throw new Error('WebGPU storage limits are too small');
      const extent = tileSize + 2 * HALO;
      const compute = async code => {
        const module = device.createShaderModule({
          code
        });
        const info = await module.getCompilationInfo();
        const errors = info.messages.filter(message => message.type === 'error');
        if (errors.length) throw new Error(errors.map(message => `${message.lineNum}:${message.linePos} ${message.message}`).join('\n'));
        return device.createComputePipelineAsync({
          layout: 'auto',
          compute: {
            module,
            entryPoint: 'main'
          }
        });
      };
      const [initialize, layers] = await Promise.all([compute(INITIALIZE), Promise.all(model.layers.map((layer, i) => compute(convolutionShader(layer, i === 4))))]);
      const module = device.createShaderModule({
        code: outputShader(model.scale, model.outputBias)
      });
      const render = await device.createRenderPipelineAsync({
        layout: 'auto',
        vertex: {
          module,
          entryPoint: 'vertex'
        },
        fragment: {
          module,
          entryPoint: 'fragment',
          targets: [{
            format
          }]
        },
        primitive: {
          topology: 'triangle-list'
        }
      });
      const learned = model.layers.map(layer => {
        const data = packParameters(layer);
        return buffer(data.byteLength, BU.STORAGE, data);
      });
      const activations = [buffer(extent * extent * 32 * 4, BU.STORAGE), buffer(extent * extent * 32 * 4, BU.STORAGE)];
      const sampler = device.createSampler({
        magFilter: 'linear',
        minFilter: 'linear',
        addressModeU: 'clamp-to-edge',
        addressModeV: 'clamp-to-edge'
      });
      const group = (pipeline, entries) => device.createBindGroup({
        layout: pipeline.getBindGroupLayout(0),
        entries: entries.map((resource, binding) => ({
          binding,
          resource: (resource === null || resource === void 0 ? void 0 : resource.size) !== undefined ? {
            buffer: resource
          } : resource
        }))
      });
      const configure = (width, height) => {
        var _frame, _frame2;
        check();
        if (!Number.isInteger(width) || !Number.isInteger(height) || width < 1 || height < 1 || width * model.scale > device.limits.maxTextureDimension2D || height * model.scale > device.limits.maxTextureDimension2D) throw new Error('Unsupported decoded frame dimensions');
        if (((_frame = frame) === null || _frame === void 0 ? void 0 : _frame.width) === width && ((_frame2 = frame) === null || _frame2 === void 0 ? void 0 : _frame2.height) === height) return;
        disposeFrame();
        const image = own(device.createTexture({
          size: [width, height],
          format: 'rgba8unorm',
          usage: TU.TEXTURE_BINDING | TU.COPY_DST | TU.RENDER_ATTACHMENT
        }));
        const owned = [image],
          tiles = [];
        try {
          const output = own(device.createTexture({
            size: [width * model.scale, height * model.scale],
            format,
            usage: TU.RENDER_ATTACHMENT | TU.COPY_SRC
          }));
          owned.push(output);
          for (let y = 0; y < height; y += tileSize) for (let x = 0; x < width; x += tileSize) {
            const data = new Int32Array([x - HALO, y - HALO, width, height, extent, extent, 0, 0]);
            const params = buffer(32, BU.UNIFORM, data);
            owned.push(params);
            tiles.push({
              x,
              y,
              params,
              init: group(initialize, [image.createView(), activations[0], params]),
              layers: layers.map((pipeline, i) => group(pipeline, [activations[i % 2], activations[(i + 1) % 2], learned[i], params])),
              render: group(render, [image.createView(), sampler, activations[1], params])
            });
          }
          canvas.width = width * model.scale;
          canvas.height = height * model.scale;
          context.configure({
            device,
            format,
            alphaMode: 'opaque',
            usage: TU.RENDER_ATTACHMENT | TU.COPY_DST
          });
          frame = {
            width,
            height,
            image,
            output,
            tiles,
            resources: owned
          };
        } catch (error) {
          for (const resource of owned) release(resource);
          throw error;
        }
      };
      const dispatch = (encoder, pipeline, bindGroup, count) => {
        const pass = encoder.beginComputePass();
        pass.setPipeline(pipeline);
        pass.setBindGroup(0, bindGroup);
        pass.dispatchWorkgroups(Math.ceil(count / THREADS));
        pass.end();
      };
      const convolve = (encoder, tile) => {
        for (let i = 0; i < layers.length; i++) dispatch(encoder, layers[i], tile.layers[i], extent * extent * Math.ceil(model.layers[i].outChannels / 4));
      };
      const run = async operation => {
        check();
        if (busy) throw new Error('An AI frame is already in flight');
        busy = true;
        try {
          return await operation();
        } finally {
          busy = false;
        }
      };
      check();
      return {
        processFrame: (source, {
          onProgress
        } = {}) => run(async () => {
          const width = source.videoWidth || source.width,
            height = source.videoHeight || source.height;
          if ('readyState' in source && source.readyState < 2) throw new Error('No decoded video frame is available');
          configure(width, height);
          const mediaTime = Number.isFinite(source.currentTime) ? source.currentTime : null;
          device.queue.copyExternalImageToTexture({
            source
          }, {
            texture: frame.image,
            colorSpace: 'srgb',
            premultipliedAlpha: false
          }, [width, height]);
          const output = frame.output.createView(),
            total = frame.tiles.length;
          for (let start = 0; start < total; start += 4) {
            const encoder = device.createCommandEncoder(),
              completed = Math.min(start + 4, total);
            for (let i = start; i < completed; i++) {
              const tile = frame.tiles[i];
              dispatch(encoder, initialize, tile.init, extent * extent);
              convolve(encoder, tile);
              const pass = encoder.beginRenderPass({
                colorAttachments: [{
                  view: output,
                  loadOp: i ? 'load' : 'clear',
                  storeOp: 'store',
                  clearValue: {
                    r: 0,
                    g: 0,
                    b: 0,
                    a: 1
                  }
                }]
              });
              pass.setPipeline(render);
              pass.setBindGroup(0, tile.render);
              pass.setScissorRect(tile.x * model.scale, tile.y * model.scale, Math.min(tileSize, width - tile.x) * model.scale, Math.min(tileSize, height - tile.y) * model.scale);
              pass.draw(3);
              pass.end();
            }
            device.queue.submit([encoder.finish()]);
            await device.queue.onSubmittedWorkDone();
            check();
            onProgress === null || onProgress === void 0 ? void 0 : onProgress({
              completed,
              total
            });
            check();
          }
          const encoder = device.createCommandEncoder();
          encoder.copyTextureToTexture({
            texture: frame.output
          }, {
            texture: context.getCurrentTexture()
          }, [canvas.width, canvas.height]);
          device.queue.submit([encoder.finish()]);
          await device.queue.onSubmittedWorkDone();
          check();
          return {
            width: canvas.width,
            height: canvas.height,
            ...(mediaTime === null ? {} : {
              mediaTime
            })
          };
        }),
        gpuInfo,
        lost: device.lost,
        destroy
      };
    } catch (error) {
      destroy();
      throw error;
    }
  }

  const idle = () => ({
    state: 'inactive',
    inputWidth: null,
    inputHeight: null,
    outputWidth: null,
    outputHeight: null,
    fps: 0,
    scale: null,
    error: null,
    phase: null,
    progress: null,
    frameTimeMs: null,
    gpuLabel: null
  });
  const problem = (code, message) => Object.assign(new Error(message), {
    code
  });
  const WARMUP_TIMEOUT = 15000,
    FRAME_TIMEOUT = 5000,
    PROGRESS_TIMEOUT = 3000,
    MAX_FRAME_AGE = 120,
    MAX_OVERLAY_AGE = 100;
  const CANCELLED = Symbol('cancelled AI frame');
  async function loadPackagedModel(scale) {
    const response = await fetch(chrome.runtime.getURL(`models/fsrcnn-small-x${scale}.json`));
    if (!response.ok) throw problem('AI_MODEL_UNAVAILABLE', 'Không tải được mô hình AI trong extension. Hãy cài lại bản đầy đủ.');
    return response.json();
  }
  function createAiController({
    document,
    createEngine = createWebGpuUpscaler,
    loadModel = loadPackagedModel
  }) {
    const view = document.defaultView;
    let status = idle(),
      session = null,
      sequence = 0;
    const snapshot = () => ({
      ...status
    });
    const current = value => session === value;
    const watchId = () => {
      const url = new URL(view.location.href);
      return view.top === view && url.origin === 'https://www.youtube.com' && url.pathname === '/watch' ? url.searchParams.get('v') : null;
    };
    const findVideo = () => document.querySelector('#movie_player video.html5-main-video');
    const adShowing = value => value.player.matches('.ad-showing,.ad-interrupting');
    function cancelFrame(value) {
      var _value$video$cancelVi, _value$video;
      if (value.frameId !== null) (_value$video$cancelVi = (_value$video = value.video).cancelVideoFrameCallback) === null || _value$video$cancelVi === void 0 ? void 0 : _value$video$cancelVi.call(_value$video, value.frameId);
      value.frameId = null;
    }
    function hide(value) {
      clearTimer(value, 'freshnessId');
      value.canvas.hidden = true;
      if (value.container.getAttribute('data-crossz-ai-active') === value.owner) value.container.removeAttribute('data-crossz-ai-active');
      if (current(value)) status = {
        ...status,
        state: 'starting',
        phase: value.warmup ? 'warmup' : 'processing',
        fps: 0
      };
    }
    function clearTimer(value, key) {
      if (value[key] !== null) view.clearTimeout(value[key]);
      value[key] = null;
    }
    function ageMs(video, mediaTime) {
      return Math.abs(video.currentTime - mediaTime) * 1000 / (Math.abs(video.playbackRate) || 1);
    }
    function armFreshness(value) {
      clearTimer(value, 'freshnessId');
      if (!current(value) || value.canvas.hidden || value.video.paused) return;
      const age = ageMs(value.video, value.presentedMediaTime);
      if (age >= MAX_OVERLAY_AGE) {
        hide(value);
        return;
      }
      value.freshnessId = view.setTimeout(() => armFreshness(value), Math.max(16, MAX_OVERLAY_AGE - age));
    }
    function clean(value) {
      var _value$cancelProcessi, _value$observer, _value$resizeObserver, _value$engine;
      if (!value) return;
      value.frameGeneration++;
      cancelFrame(value);
      clearTimer(value, 'watchdogId');
      clearTimer(value, 'progressWatchdogId');
      clearTimer(value, 'freshnessId');
      value.rearmBudget = null;
      (_value$cancelProcessi = value.cancelProcessing) === null || _value$cancelProcessi === void 0 ? void 0 : _value$cancelProcessi.call(value);
      value.cancelProcessing = null;
      hide(value);
      (_value$observer = value.observer) === null || _value$observer === void 0 ? void 0 : _value$observer.disconnect();
      (_value$resizeObserver = value.resizeObserver) === null || _value$resizeObserver === void 0 ? void 0 : _value$resizeObserver.disconnect();
      for (const dispose of value.listeners) dispose();
      value.listeners = [];
      value.canvas.remove();
      (_value$engine = value.engine) === null || _value$engine === void 0 ? void 0 : _value$engine.destroy();
      value.engine = null;
    }
    function stop() {
      const previous = session;
      session = null;
      clean(previous);
      status = idle();
      return snapshot();
    }
    function fail(error, value = session) {
      if (value && !current(value)) return;
      const previous = session;
      session = null;
      clean(previous);
      status = {
        ...status,
        state: 'error',
        phase: null,
        progress: null,
        fps: 0,
        error: (error === null || error === void 0 ? void 0 : error.message) || 'Không thể xử lý video bằng AI.'
      };
    }
    function supported(video, player) {
      var _view$ambientlight, _view$ambientlight2;
      if (video.mediaKeys || video.webkitMediaKeys) throw problem('AI_PROTECTED_VIDEO', 'Video được bảo vệ DRM nên AI không thể đọc khung hình.');
      if (document.pictureInPictureElement === video) throw problem('AI_UNSUPPORTED_PIP', 'AI chưa hỗ trợ cửa sổ hình trong hình. Video gốc vẫn phát.');
      if ((_view$ambientlight = view.ambientlight) !== null && _view$ambientlight !== void 0 && _view$ambientlight.isHdr) throw problem('AI_UNSUPPORTED_HDR', 'AI hiện chỉ hỗ trợ video SDR, chưa hỗ trợ HDR.');
      if (!view.VideoFrame) throw problem('AI_UNSUPPORTED_BROWSER', 'Hãy cập nhật Edge để kiểm tra màu sắc và quyền đọc khung hình video.');
      let frame;
      try {
        var _frame$colorSpace, _frame$colorSpace2;
        frame = new view.VideoFrame(video);
        const transfer = (_frame$colorSpace = frame.colorSpace) === null || _frame$colorSpace === void 0 ? void 0 : _frame$colorSpace.transfer,
          primaries = (_frame$colorSpace2 = frame.colorSpace) === null || _frame$colorSpace2 === void 0 ? void 0 : _frame$colorSpace2.primaries;
        if (['smpte2084', 'arib-std-b67', 'pq', 'hlg'].includes(transfer) || primaries === 'bt2020') throw problem('AI_UNSUPPORTED_HDR', 'AI hiện chỉ hỗ trợ video SDR, chưa hỗ trợ HDR hoặc màu BT.2020.');
      } catch (error) {
        if (error.code === 'AI_UNSUPPORTED_HDR') throw error;
        throw problem('AI_FRAME_UNAVAILABLE', 'AI không có quyền đọc khung hình video này. Video gốc vẫn phát.');
      } finally {
        var _frame;
        (_frame = frame) === null || _frame === void 0 ? void 0 : _frame.close();
      }
      if ((_view$ambientlight2 = view.ambientlight) !== null && _view$ambientlight2 !== void 0 && _view$ambientlight2.isVrVideo || player.classList.contains('ytp-webgl-spherical')) throw problem('AI_UNSUPPORTED_VR', 'AI chưa hỗ trợ video VR hoặc 360°.');
      if (document.hidden) throw problem('AI_PAGE_HIDDEN', 'Mở lại tab video rồi bật AI.');
    }
    function unchanged(value) {
      return value.video.isConnected && value.container.isConnected && findVideo() === value.video && watchId() === value.watchId && value.video.srcObject === value.sourceObject && (value.video.currentSrc || value.video.src) === value.source && value.video.videoWidth === status.inputWidth && value.video.videoHeight === status.inputHeight;
    }
    function layout(value) {
      if (!current(value)) return;
      const style = view.getComputedStyle(value.video);
      Object.assign(value.canvas.style, {
        left: `${value.video.offsetLeft}px`,
        top: `${value.video.offsetTop}px`,
        width: `${value.video.clientWidth}px`,
        height: `${value.video.clientHeight}px`,
        transform: style.transform,
        transformOrigin: style.transformOrigin,
        objectFit: style.objectFit,
        objectPosition: style.objectPosition,
        borderRadius: style.borderRadius
      });
    }
    function schedule(value, force = false) {
      if (!current(value)) return;
      if (force) value.refreshRequested = true;
      if (!value.engine || value.inFlight || value.frameId !== null || value.video.seeking || adShowing(value)) return;
      const refresh = value.refreshRequested;
      value.refreshRequested = false;
      if (value.video.paused) {
        if (refresh) view.queueMicrotask(() => {
          if (current(value) && !value.inFlight) void process(value);
        });
        return;
      }
      value.frameId = value.video.requestVideoFrameCallback(timestamp => {
        value.frameId = null;
        if (!refresh && timestamp < value.nextAllowed) {
          schedule(value);
          return;
        }
        void process(value);
      });
    }
    async function process(value) {
      if (!current(value) || value.inFlight || value.video.seeking || adShowing(value)) return;
      if (!unchanged(value)) {
        stop();
        return;
      }
      const frameGeneration = value.frameGeneration;
      try {
        supported(value.video, value.player);
        if (value.video.readyState < 2) {
          hide(value);
          schedule(value);
          return;
        }
        value.inFlight = true;
        const began = view.performance.now(),
          capturedTime = value.video.currentTime,
          wasWarmup = value.warmup,
          workId = ++value.workSequence;
        const validWork = () => current(value) && value.inFlight && value.workSequence === workId;
        let completedTiles = 0;
        status = {
          ...status,
          phase: wasWarmup ? 'warmup' : 'processing',
          progress: null
        };
        armFreshness(value);
        const cancelled = new Promise(resolve => {
          value.cancelProcessing = () => resolve(CANCELLED);
        });
        let armProgress;
        const timedOut = new Promise((_resolve, reject) => {
          value.rearmBudget = () => {
            clearTimer(value, 'watchdogId');
            if (!validWork()) return;
            const budget = wasWarmup || value.video.paused ? WARMUP_TIMEOUT : FRAME_TIMEOUT;
            value.watchdogId = view.setTimeout(() => {
              if (validWork()) reject(problem('AI_FRAME_TIMEOUT', `${wasWarmup ? 'Khung AI đầu tiên' : 'Khung AI'} chưa hoàn tất sau ${budget / 1000} giây. Video gốc vẫn phát; bật AI để thử lại.`));
            }, Math.max(0, budget - (view.performance.now() - began)));
          };
          armProgress = () => {
            clearTimer(value, 'progressWatchdogId');
            value.progressWatchdogId = view.setTimeout(() => {
              if (validWork()) reject(problem('AI_PROGRESS_TIMEOUT', 'AI không cập nhật tiến độ trong 3 giây. Đã trở về video gốc; bật AI để thử lại.'));
            }, PROGRESS_TIMEOUT);
          };
          value.rearmBudget();
          if (!wasWarmup) armProgress();
        });
        const result = await Promise.race([value.engine.processFrame(value.video, {
          onProgress: progress => {
            if (!validWork() || !Number.isInteger(progress === null || progress === void 0 ? void 0 : progress.completed) || !Number.isInteger(progress === null || progress === void 0 ? void 0 : progress.total) || progress.completed <= completedTiles || progress.completed > progress.total) return;
            completedTiles = progress.completed;
            armProgress();
            if (frameGeneration === value.frameGeneration) status = {
              ...status,
              progress: {
                completed: progress.completed,
                total: progress.total
              }
            };
          }
        }), cancelled, timedOut]);
        if (result === CANCELLED || !current(value)) return;
        value.warmup = false;
        if (frameGeneration !== value.frameGeneration) return;
        if (!unchanged(value)) {
          stop();
          return;
        }
        if (value.video.seeking || adShowing(value)) {
          hide(value);
          return;
        }
        supported(value.video, value.player);
        if (value.canvas.width !== 3840 || value.canvas.height !== 2160) throw problem('AI_INVALID_OUTPUT', 'Đầu ra AI không đạt 3840×2160. Đã trở về video gốc.');
        const completed = view.performance.now(),
          duration = completed - began;
        status = {
          ...status,
          frameTimeMs: Math.round(duration * 10) / 10,
          progress: null
        };
        if (!wasWarmup && !value.video.paused) {
          value.slowFrames = duration > 100 ? value.slowFrames + 1 : 0;
          value.averageDuration = value.averageDuration ? value.averageDuration * 0.75 + duration * 0.25 : duration;
        } else if (value.video.paused) value.slowFrames = 0;
        value.nextAllowed = began + Math.max(1000 / 30, value.averageDuration * 1.2);
        if (value.slowFrames >= 3) throw problem('AI_TOO_SLOW', `GPU xử lý quá chậm (${Math.round(duration)} ms/khung). Đã trở về video gốc; thử nguồn 720p hoặc tắt bớt hiệu ứng.${value.softwareGpu ? ' Trình duyệt đang dùng GPU phần mềm.' : ''}`);
        const mediaTime = Number.isFinite(result === null || result === void 0 ? void 0 : result.mediaTime) ? result.mediaTime : capturedTime;
        const stale = value.video.paused ? Math.abs(value.video.currentTime - mediaTime) > 0.001 : ageMs(value.video, mediaTime) > MAX_FRAME_AGE;
        if (stale) {
          hide(value);
          return;
        }
        layout(value);
        value.canvas.hidden = false;
        value.container.setAttribute('data-crossz-ai-active', value.owner);
        value.presentedMediaTime = mediaTime;
        const fps = value.lastCompleted ? 1000 / Math.max(1, completed - value.lastCompleted) : 0;
        value.lastCompleted = completed;
        status = {
          ...status,
          state: 'active',
          phase: 'ready',
          error: null,
          fps: value.video.paused ? 0 : Math.round(fps * 10) / 10
        };
        armFreshness(value);
      } catch (error) {
        if (current(value)) fail(error, value);
      } finally {
        clearTimer(value, 'watchdogId');
        clearTimer(value, 'progressWatchdogId');
        value.rearmBudget = null;
        value.cancelProcessing = null;
        value.inFlight = false;
        schedule(value);
      }
    }
    function listen(value, target, type, handler) {
      target.addEventListener(type, handler);
      value.listeners.push(() => target.removeEventListener(type, handler));
    }
    function observe(value) {
      for (const name of ['loadstart', 'emptied', 'enterpictureinpicture']) listen(value, value.video, name, stop);
      listen(value, value.video, 'encrypted', () => fail(problem('AI_PROTECTED_VIDEO', 'Video được bảo vệ DRM nên AI không thể đọc khung hình.'), value));
      listen(value, document, 'yt-navigate-start', stop);
      listen(value, view, 'pagehide', stop);
      listen(value, document, 'visibilitychange', () => {
        if (document.hidden) stop();
      });
      listen(value, value.video, 'resize', () => {
        if (!unchanged(value)) stop();else layout(value);
      });
      listen(value, value.video, 'seeking', () => {
        value.frameGeneration++;
        cancelFrame(value);
        hide(value);
        status = {
          ...status,
          state: 'starting',
          fps: 0
        };
      });
      listen(value, value.video, 'seeked', () => schedule(value, true));
      listen(value, value.video, 'playing', () => {
        var _value$rearmBudget;
        (_value$rearmBudget = value.rearmBudget) === null || _value$rearmBudget === void 0 ? void 0 : _value$rearmBudget.call(value);
        armFreshness(value);
        schedule(value, true);
      });
      listen(value, value.video, 'pause', () => {
        var _value$rearmBudget2;
        (_value$rearmBudget2 = value.rearmBudget) === null || _value$rearmBudget2 === void 0 ? void 0 : _value$rearmBudget2.call(value);
        if (value.inFlight) value.frameGeneration++;
        cancelFrame(value);
        hide(value);
        schedule(value, true);
      });
      value.observer = new view.MutationObserver(() => {
        if (!current(value)) return;
        if (!unchanged(value)) {
          stop();
          return;
        }
        const ad = adShowing(value);
        if (ad !== value.ad) {
          value.ad = ad;
          value.frameGeneration++;
          cancelFrame(value);
          hide(value);
          status = {
            ...status,
            state: 'starting',
            fps: 0
          };
          if (!ad) schedule(value, true);
        }
        layout(value);
      });
      value.observer.observe(document.documentElement, {
        childList: true,
        subtree: true
      });
      value.observer.observe(value.player, {
        attributes: true,
        attributeFilter: ['class']
      });
      if (view.ResizeObserver) {
        value.resizeObserver = new view.ResizeObserver(() => layout(value));
        value.resizeObserver.observe(value.video);
      }
      listen(value, view, 'resize', () => layout(value));
      listen(value, document, 'fullscreenchange', () => layout(value));
    }
    async function start() {
      if (session) return snapshot();
      status = idle();
      let value;
      try {
        var _engine$device;
        const id = watchId();
        if (!id) throw problem('AI_UNSUPPORTED_PAGE', 'Mở một video YouTube thông thường để bật AI 4K.');
        const video = findVideo(),
          player = video === null || video === void 0 ? void 0 : video.closest('.html5-video-player'),
          container = video === null || video === void 0 ? void 0 : video.closest('.html5-video-container');
        if (!(video !== null && video !== void 0 && video.isConnected) || !player || !container || video.readyState < 2) throw problem('AI_PLAYER_NOT_READY', 'Video chưa sẵn sàng. Hãy phát video rồi thử lại.');
        status = {
          ...status,
          inputWidth: video.videoWidth,
          inputHeight: video.videoHeight
        };
        supported(video, player);
        const scale = video.videoWidth === 1920 && video.videoHeight === 1080 ? 2 : video.videoWidth === 1280 && video.videoHeight === 720 ? 3 : null;
        if (!scale) throw problem('AI_UNSUPPORTED_RESOLUTION', `AI 4K cần video gốc 1280×720 hoặc 1920×1080. Hiện tại: ${video.videoWidth}×${video.videoHeight}.`);
        if (!video.requestVideoFrameCallback) throw problem('AI_UNSUPPORTED_BROWSER', 'Trình duyệt chưa hỗ trợ xử lý theo khung hình video. Hãy cập nhật Edge.');
        const canvas = document.createElement('canvas');
        canvas.className = 'crossz-ai-canvas';
        canvas.width = 3840;
        canvas.height = 2160;
        canvas.hidden = true;
        canvas.setAttribute('aria-hidden', 'true');
        value = {
          video,
          player,
          container,
          canvas,
          watchId: id,
          source: video.currentSrc || video.src,
          sourceObject: video.srcObject,
          owner: `crossz-${++sequence}`,
          engine: null,
          listeners: [],
          observer: null,
          resizeObserver: null,
          frameId: null,
          frameGeneration: 0,
          inFlight: false,
          refreshRequested: false,
          watchdogId: null,
          progressWatchdogId: null,
          freshnessId: null,
          rearmBudget: null,
          cancelProcessing: null,
          warmup: true,
          workSequence: 0,
          slowFrames: 0,
          averageDuration: 0,
          nextAllowed: 0,
          presentedMediaTime: 0,
          lastCompleted: 0,
          softwareGpu: false,
          ad: false
        };
        session = value;
        status = {
          ...status,
          state: 'starting',
          phase: 'model',
          scale,
          outputWidth: 3840,
          outputHeight: 2160
        };
        container.appendChild(canvas);
        observe(value);
        layout(value);
        const model = await loadModel(scale);
        if (!current(value)) return snapshot();
        if ((model === null || model === void 0 ? void 0 : model.scale) !== scale) throw problem('AI_INVALID_MODEL', 'Mô hình AI không khớp độ phân giải video. Hãy cài lại bản đầy đủ.');
        status = {
          ...status,
          phase: 'gpu'
        };
        const engine = await createEngine({
          canvas,
          model
        });
        if (!current(value)) {
          engine.destroy();
          return snapshot();
        }
        value.engine = engine;
        const info = engine.gpuInfo || {};
        value.softwareGpu = info.isFallbackAdapter === true;
        const label = String(info.description || info.vendor || '').trim();
        status = {
          ...status,
          phase: 'warmup',
          gpuLabel: value.softwareGpu ? `GPU phần mềm${label ? ' · ' + label : ''}` : label || null
        };
        const lost = engine.lost || ((_engine$device = engine.device) === null || _engine$device === void 0 ? void 0 : _engine$device.lost);
        if (lost !== null && lost !== void 0 && lost.then) lost.then(() => {
          if (current(value)) fail(problem('AI_DEVICE_LOST', 'Mất kết nối GPU. Video đã trở về bản gốc; bật AI để thử lại.'), value);
        }).catch(error => {
          if (current(value)) fail(error, value);
        });
        schedule(value, true);
        return snapshot();
      } catch (error) {
        if (!value || current(value)) {
          fail(error, value);
          throw error;
        }
        return snapshot();
      }
    }
    return {
      start,
      stop,
      snapshot
    };
  }

  const controller = createAiController({
    document
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || (message === null || message === void 0 ? void 0 : message.channel) !== 'crossz-ai-content') return;
    if (!['AI_GET_STATE', 'AI_START', 'AI_STOP'].includes(message.type)) return;
    const action = message.type === 'AI_START' ? () => controller.start() : message.type === 'AI_STOP' ? () => controller.stop() : () => controller.snapshot();
    Promise.resolve().then(action).then(data => reply({
      ok: true,
      data
    }), error => reply({
      ok: false,
      error: {
        code: error.code || 'AI_FAILED',
        message: error.message
      }
    }));
    return true;
  });

})();
