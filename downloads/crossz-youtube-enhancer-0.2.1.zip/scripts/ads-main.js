(function () {
  'use strict';

  
  let console;

  (function () {
    const preMessage = 'Ambient light for YouTube™ |';

    const enrich = (...args) => {
      if (args.length <= 0) return args;

      if (typeof args[0] === 'string') {
        const [firstArg, ...postArgs] = args;
        return [`${preMessage} ${firstArg}`, ...postArgs];
      }

      return [preMessage, ...args];
    };

    console = {
      log: (...args) => globalThis.console.log(...enrich(...args)),
      debug: (...args) => globalThis.console.debug(...enrich(...args)),
      warn: (...args) => globalThis.console.warn(...enrich(...args)),
      error: (...args) => globalThis.console.error(...enrich(...args)),
      dir: (...args) => globalThis.console.dir(...args),
    };
  })();


  const AD_FIELDS = ['playerAds', 'adPlacements', 'adSlots'];
  function inheritedDescriptor(target, property) {
    for (let owner = target; owner; owner = Object.getPrototypeOf(owner)) {
      const descriptor = Object.getOwnPropertyDescriptor(owner, property);
      if (descriptor) return {
        owner,
        descriptor
      };
    }
  }
  function prunePlayer(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    let changed = false;
    for (const key of AD_FIELDS) {
      var _Object$getOwnPropert;
      if ((_Object$getOwnPropert = Object.getOwnPropertyDescriptor(value, key)) !== null && _Object$getOwnPropert !== void 0 && _Object$getOwnPropert.configurable) {
        delete value[key];
        changed = true;
      }
    }
    const nested = value.playerResponse;
    if (nested && typeof nested === 'object' && nested !== value) {
      for (const key of AD_FIELDS) {
        var _Object$getOwnPropert2;
        if ((_Object$getOwnPropert2 = Object.getOwnPropertyDescriptor(nested, key)) !== null && _Object$getOwnPropert2 !== void 0 && _Object$getOwnPropert2.configurable) {
          delete nested[key];
          changed = true;
        }
      }
    }
    return changed;
  }
  function installPlayerAdFilter(scope = window) {
    if (scope.location.origin !== 'https://www.youtube.com') return;
    const installed = Symbol.for('crossz.player-ad-filter');
    if (scope[installed]) return;
    Object.defineProperty(scope, installed, {
      value: true
    });
    let enabled = false;
    const isPlayerURL = url => {
      try {
        const parsed = new URL(url, scope.location.href);
        return parsed.origin === 'https://www.youtube.com' && parsed.pathname === '/youtubei/v1/player';
      } catch {
        return false;
      }
    };
    const filterValue = value => {
      if (enabled) try {
        prunePlayer(value);
      } catch {}
      return value;
    };
    const filterText = text => {
      if (!enabled || typeof text !== 'string') return text;
      try {
        const prefix = text.startsWith(")]}'\n") ? ")]}'\n" : '';
        const value = JSON.parse(text.slice(prefix.length));
        return prunePlayer(value) ? prefix + JSON.stringify(value) : text;
      } catch {
        return text;
      }
    };
    for (const key of ['ytInitialPlayerResponse', 'playerResponse']) {
      const descriptor = Object.getOwnPropertyDescriptor(scope, key);
      if (descriptor && (!descriptor.configurable || descriptor.get || descriptor.set || descriptor.writable === false)) continue;
      let value = descriptor === null || descriptor === void 0 ? void 0 : descriptor.value;
      Object.defineProperty(scope, key, {
        configurable: true,
        enumerable: (descriptor === null || descriptor === void 0 ? void 0 : descriptor.enumerable) ?? true,
        get: () => filterValue(value),
        set: next => {
          value = filterValue(next);
        }
      });
    }
    for (const method of ['json', 'text']) {
      var _scope$Response;
      const prototype = (_scope$Response = scope.Response) === null || _scope$Response === void 0 ? void 0 : _scope$Response.prototype;
      const {
        owner,
        descriptor
      } = inheritedDescriptor(prototype, method) || {};
      if (typeof (descriptor === null || descriptor === void 0 ? void 0 : descriptor.value) !== 'function') continue;
      const original = descriptor.value;
      try {
        Object.defineProperty(owner, method, {
          ...descriptor,
          value: function (...args) {
            const selected = isPlayerURL(this.url) && this.ok;
            return Reflect.apply(original, this, args).then(value => selected ? method === 'json' ? filterValue(value) : filterText(value) : value);
          }
        });
      } catch {}
    }
    const textCache = new WeakMap();
    for (const property of ['responseText', 'response']) {
      var _scope$XMLHttpRequest;
      const prototype = (_scope$XMLHttpRequest = scope.XMLHttpRequest) === null || _scope$XMLHttpRequest === void 0 ? void 0 : _scope$XMLHttpRequest.prototype;
      const {
        descriptor
      } = inheritedDescriptor(prototype, property) || {};
      if (typeof (descriptor === null || descriptor === void 0 ? void 0 : descriptor.get) !== 'function') continue;
      const original = descriptor.get;
      try {
        Object.defineProperty(prototype, property, {
          ...descriptor,
          get: function () {
            const value = Reflect.apply(original, this, []);
            if (!enabled || this.readyState !== 4 || this.status < 200 || this.status >= 300 || !isPlayerURL(this.responseURL)) return value;
            if (property === 'response' && this.responseType === 'json') return filterValue(value);
            if (typeof value !== 'string' || !['', 'text'].includes(this.responseType)) return value;
            const cached = textCache.get(this);
            if ((cached === null || cached === void 0 ? void 0 : cached.original) === value) return cached.filtered;
            const filtered = filterText(value);
            textCache.set(this, {
              original: value,
              filtered
            });
            return filtered;
          }
        });
      } catch {}
    }
    scope.document.addEventListener('crossz-ads-state', event => {
      if (typeof event.detail !== 'boolean') return;
      enabled = event.detail;
      if (enabled) for (const key of ['ytInitialPlayerResponse', 'playerResponse']) {
        try {
          filterValue(scope[key]);
        } catch {}
      }
    });
    scope.document.dispatchEvent(new scope.Event('crossz-ads-ready'));
  }

  installPlayerAdFilter();

})();
