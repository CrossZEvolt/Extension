(function () {
  'use strict';

  
  let console;

  (function () {
    const preMessage = 'Ambient light for YouTube™ |';

    const enrich = (...args) => {
      if (args.length <= 0) return args;

      if (typeof args[0] === 'string') {
        const [firstArg, ...postArgs] = args;
        return [`${preMessage} ${firstArg}`, ...postArgs];
      }

      return [preMessage, ...args];
    };

    console = {
      log: (...args) => globalThis.console.log(...enrich(...args)),
      debug: (...args) => globalThis.console.debug(...enrich(...args)),
      warn: (...args) => globalThis.console.warn(...enrich(...args)),
      error: (...args) => globalThis.console.error(...enrich(...args)),
      dir: (...args) => globalThis.console.dir(...args),
    };
  })();


  const getVersion = () => chrome.runtime.getManifest().version;

  let errorHandler = ex => {
    console.error(ex);
  };
  const setErrorHandler = handler => {
    errorHandler = handler;
  };
  const wrapErrorHandlerHandleError = (stack, ex, reportOnce, reported) => {
    if (reportOnce) {
      if (reported.includes(ex.message)) return;
      reported.push(ex.message);
    }
    appendErrorStack(stack, ex);
    if (errorHandler) errorHandler(ex);
  };
  const withErrorHandler = (callback, reportOnce, stack, reported) => {
    const callbackName = callback.name || 'anonymous';
    const container = {
      [callbackName]: (...args) => {
        try {
          return callback(...args);
        } catch (ex) {
          wrapErrorHandlerHandleError(stack, ex, reportOnce, reported);
        }
      }
    };
    return container[callbackName];
  };
  const withAsyncErrorHandler = (callback, reportOnce, stack, reported) => {
    const callbackName = callback.name || 'anonymous';
    const container = {
      [callbackName]: async (...args) => {
        try {
          return await callback(...args);
        } catch (ex) {
          wrapErrorHandlerHandleError(stack, ex, reportOnce, reported);
        }
      }
    };
    return container[callbackName];
  };
  const wrapErrorHandler = (callback, reportOnce = false) => (callback.constructor.name === 'AsyncFunction' ? withAsyncErrorHandler : withErrorHandler)(callback, reportOnce, new Error().stack, []);
  const eventListenerCallbacks = [];
  function on(elem, eventNames, callback, options, reportOnce = false) {
    try {
      const stack = new Error().stack;
      const callbacksName = `on_${eventNames.split(' ').join('_')}`;
      let reported = [];
      const namedCallbacks = {
        [callbacksName]: async (...args) => {
          try {
            await callback(...args);
          } catch (ex) {
            if (reportOnce) {
              if (reported.includes(ex.message)) return;
              reported.push(ex.message);
            }
            const e = args.length ? args[0] : {};
            const type = e.type === 'keydown' ? `${e.type} keyCode: ${e.keyCode}` : e.type;
            ex.message = `${ex.message} \nOn event: ${type}`;
            try {
              if (elem) {
                ex.message = `${ex.message} \nElem: ${elem.toString()} ${elem.nodeName || ''}#${elem.id || ''}.${elem.className || ''}`;
              }
            } catch (elemEx) {
              ex.details = {
                ...(ex.details || {}),
                elemEx
              };
            }
            try {
              if (e !== null && e !== void 0 && e.target) {
                ex.message = `${ex.message} \nTarget: ${e.target.toString()} ${e.target.nodeName || ''}#${e.target.id || ''}.${e.target.className || ''}`;
              }
            } catch (targetEx) {
              ex.details = {
                ...(ex.details || {}),
                targetEx
              };
            }
            try {
              if (e !== null && e !== void 0 && e.currentTarget) {
                ex.message = `${ex.message} \nCurrentTarget: ${e.currentTarget.toString()} ${e.currentTarget.nodeName || ''}#${e.currentTarget.id || ''}.${e.currentTarget.className || ''}`;
              }
            } catch (currentTargetEx) {
              ex.details = {
                ...(ex.details || {}),
                currentTargetEx
              };
            }
            ex.details = {
              ...(ex.details || {}),
              eventNames,
              options,
              reportOnce
            };
            appendErrorStack(stack, ex);
            if (errorHandler) errorHandler(ex);
          }
        }
      };
      const eventListenerCallback = namedCallbacks[callbacksName];
      const eventNamesList = eventNames.split(' ');
      const existingEventListenerCallback = eventListenerCallbacks.find(e => e.args.elem === elem && e.args.callback === callback && JSON.stringify(e.args.options) === JSON.stringify(options));
      for (const eventName of eventNamesList) {
        if (existingEventListenerCallback) {
          if (existingEventListenerCallback.args.eventNamesList.includes(eventName)) {
            continue;
          } else {
            existingEventListenerCallback.args.eventNamesList.push(eventName);
          }
        }
        elem.addEventListener(eventName, eventListenerCallback, options);
      }
      if (!existingEventListenerCallback) {
        eventListenerCallbacks.push({
          args: {
            elem,
            eventNamesList,
            callback,
            options
          },
          callback: eventListenerCallback
        });
      }
    } catch (ex) {
      ex.details = {
        eventNames,
        options,
        reportOnce
      };
      try {
        if (elem) {
          ex.message = `${ex.message} \nFor element: ${elem.toString()} ${elem.nodeName || ''}#${elem.id || ''}.${elem.className || ''}`;
        }
      } catch (elemEx) {
        ex.details = {
          ...(ex.details || {}),
          elemEx
        };
      }
      console.log('catched', ex);
      throw ex;
    }
  }
  globalThis.matchMedia('(color-gamut: p3)').matches ? 'display-p3' : 'srgb';
  globalThis.matchMedia('(color-gamut: rec2020)').matches ? 'rec2020' : globalThis.matchMedia('(color-gamut: p3)').matches ? 'display-p3' : 'srgb';
  const appendErrorStack = (stack, ex) => {
    try {
      var _ref;
      const stackToAppend = stack === null || stack === void 0 ? void 0 : stack.substring((stack === null || stack === void 0 ? void 0 : stack.indexOf('\n')) + 1);
      const stackToSearch = stackToAppend === null || stackToAppend === void 0 ? void 0 : stackToAppend.substring((stackToAppend === null || stackToAppend === void 0 ? void 0 : stackToAppend.indexOf('\n')) + 1);
      const alreadyContainsStack = ((_ref = (ex === null || ex === void 0 ? void 0 : ex.stack) || (ex === null || ex === void 0 ? void 0 : ex.message) || (ex === null || ex === void 0 ? void 0 : ex.toString())) === null || _ref === void 0 ? void 0 : _ref.indexOf(stackToSearch)) !== -1;
      if (!alreadyContainsStack) {
        ex.stack = `${ex.stack || ex.message || ex.toString()}\n${stackToAppend}`;
      }
    } catch (ex) {
      console.warn(ex);
    }
  };
  let warningElem;
  let warningElemText;
  const setWarning = text => {
    if (!warningElem) {
      const elem = document.createElement('div');
      elem.style.position = 'fixed';
      elem.style.zIndex = 999999;
      elem.style.left = 0;
      elem.style.bottom = 0;
      elem.style.padding = '5px 8px';
      elem.style.background = 'rgba(0,0,0,.99)';
      elem.style.color = '#fff';
      elem.style.border = '1px solid #f80';
      elem.style.borderTopRightRadius = '3px';
      elem.style.whiteSpace = 'pre-wrap';
      elem.style.fontSize = '15px';
      elem.style.lineHeight = '18px';
      elem.style.fontFamily = 'sans-serif';
      elem.style.overflowWrap = 'anywhere';
      elem.style.overflow = 'hidden';
      warningElem = elem;
      const closeButton = document.createElement('button');
      closeButton.style.position = 'absolute';
      closeButton.style.zIndex = 2;
      closeButton.style.right = 0;
      closeButton.style.top = 0;
      closeButton.style.border = 'none';
      closeButton.style.borderBottomLeftRadius = '3px';
      closeButton.style.padding = '0px 8px';
      closeButton.style.background = '#f80';
      closeButton.style.fontWeight = 'bold';
      closeButton.style.fontFamily = 'inherit';
      closeButton.style.lineHeight = '20px';
      closeButton.style.fontSize = '22px';
      closeButton.style.color = '#000';
      closeButton.style.cursor = 'pointer';
      closeButton.textContent = 'x';
      on(closeButton, 'click', () => setWarning(''));
      elem.appendChild(closeButton);
      const titleElem = document.createElement('div');
      titleElem.style.fontWeight = 'bold';
      titleElem.style.color = '#008cff';
      titleElem.style.fontSize = '22px';
      titleElem.style.lineHeight = '28px';
      titleElem.textContent = 'Ambient light for YouTube™\n';
      elem.appendChild(titleElem);
      const textElem = document.createElement('div');
      warningElemText = textElem;
      elem.appendChild(textElem);
    }
    const elem = warningElem;
    if (text) {
      warningElemText.textContent = text;
      document.documentElement.appendChild(elem);
    } else {
      warningElemText.textContent = '';
      elem.remove();
    }
  };

  class Storage {
    constructor() {
      this.onChangedListeners = [];
    }
    async set(nameOrNamesAndValues, value = undefined, throwOnUninstalled = false) {
      try {
        const multiple = typeof nameOrNamesAndValues !== 'string';
        const namesAndValues = multiple ? nameOrNamesAndValues : {
          [nameOrNamesAndValues]: value
        };
        const stack = new Error().stack;
        return await new Promise(function storageSet(resolve, reject) {
          try {
            var _chrome, _chrome$runtime;
            if (!((_chrome = chrome) !== null && _chrome !== void 0 && (_chrome$runtime = _chrome.runtime) !== null && _chrome$runtime !== void 0 && _chrome$runtime.id)) throw new Error('uninstalled');
            const setCallback = () => {
              try {
                if (chrome.runtime.lastError) throw chrome.runtime.lastError;
                resolve();
              } catch (ex) {
                var _chrome2, _chrome2$runtime;
                if (!((_chrome2 = chrome) !== null && _chrome2 !== void 0 && (_chrome2$runtime = _chrome2.runtime) !== null && _chrome2$runtime !== void 0 && _chrome2$runtime.id)) return reject(new Error('uninstalled'));
                appendErrorStack(stack, ex);
                reject(ex);
              }
            };
            if (!multiple && value === undefined) {
              chrome.storage.local.remove([nameOrNamesAndValues], setCallback);
            } else {
              chrome.storage.local.set(namesAndValues, setCallback);
            }
          } catch (ex) {
            var _chrome3, _chrome3$runtime;
            if (!((_chrome3 = chrome) !== null && _chrome3 !== void 0 && (_chrome3$runtime = _chrome3.runtime) !== null && _chrome3$runtime !== void 0 && _chrome3$runtime.id)) return reject(new Error('uninstalled'));
            appendErrorStack(stack, ex);
            reject(ex);
          }
        });
      } catch (ex) {
        var _ex$message;
        if (ex && (throwOnUninstalled || !(ex.message === 'uninstalled' || (_ex$message = ex.message) !== null && _ex$message !== void 0 && _ex$message.includes('QuotaExceededError')))) throw ex;
      }
    }
    async get(nameOrNames, throwOnUninstalled = false) {
      try {
        const multiple = typeof nameOrNames !== 'string';
        const names = multiple ? nameOrNames : [nameOrNames];
        const stack = new Error().stack;
        return await new Promise(function storageGet(resolve, reject) {
          try {
            var _chrome4, _chrome4$runtime;
            if (!((_chrome4 = chrome) !== null && _chrome4 !== void 0 && (_chrome4$runtime = _chrome4.runtime) !== null && _chrome4$runtime !== void 0 && _chrome4$runtime.id)) throw new Error('uninstalled');
            chrome.storage.local.get(names, function getCallback(result) {
              try {
                if (chrome.runtime.lastError) throw chrome.runtime.lastError;
                resolve(multiple ? result : result[nameOrNames] === undefined ? null : result[nameOrNames]);
              } catch (ex) {
                var _chrome5, _chrome5$runtime;
                if (!((_chrome5 = chrome) !== null && _chrome5 !== void 0 && (_chrome5$runtime = _chrome5.runtime) !== null && _chrome5$runtime !== void 0 && _chrome5$runtime.id)) return reject(new Error('uninstalled'));
                appendErrorStack(stack, ex);
                reject(ex);
              }
            });
          } catch (ex) {
            var _chrome6, _chrome6$runtime;
            if (!((_chrome6 = chrome) !== null && _chrome6 !== void 0 && (_chrome6$runtime = _chrome6.runtime) !== null && _chrome6$runtime !== void 0 && _chrome6$runtime.id)) return reject(new Error('uninstalled'));
            appendErrorStack(stack, ex);
            reject(ex);
          }
        });
      } catch (ex) {
        var _ex$message2;
        if (ex && (throwOnUninstalled || !(ex.message === 'uninstalled' || (_ex$message2 = ex.message) !== null && _ex$message2 !== void 0 && _ex$message2.includes('QuotaExceededError')))) throw ex;
      }
    }
    addListener(handler) {
      try {
        const wrappedHandler = wrapErrorHandler(handler, true);
        chrome.storage.local.onChanged.addListener(wrappedHandler);
        this.onChangedListeners.push({
          handler,
          wrappedHandler
        });
      } catch (ex) {
        console.warn("Failed to listen to storage changes. If any setting changes you'll have to manually refresh the page to update them.");
        console.debug(ex);
      }
    }
    removeListener(handler) {
      try {
        const entry = this.onChangedListeners.find(entry => entry.handler === handler);
        if (!entry) throw new Error('Cannot remove a storage.local.onChange listener that has never been added');
        chrome.storage.local.onChanged.removeListener(entry.wrappedHandler);
        this.onChangedListeners.splice(this.onChangedListeners.indexOf(entry), 1);
      } catch {
        console.warn("Failed to listen to storage changes. If any setting changes you'll have to manually refresh the page to update them.");
      }
    }
  }
  const storage = new Storage();
  const defaultCrashOptions = {
    video: false,
    technical: false,
    crash: true
  };

  const KEY = 'crossz-local-errors';
  function createLocalReporter({
    read,
    write
  }) {
    let pending = Promise.resolve();
    return {
      record(error) {
        const entry = {
          time: new Date().toISOString(),
          name: String((error === null || error === void 0 ? void 0 : error.name) || 'Error').slice(0, 80),
          message: String((error === null || error === void 0 ? void 0 : error.message) || error).replace(/(?:https?:|chrome-extension:|blob:)[^\s)]+/g, '[URL]').replace(/(?:streamId|chromeMediaSourceId)[=: ]+\S+/gi, '[stream]').slice(0, 1000)
        };
        pending = pending.catch(() => {}).then(async () => {
          const previous = await read();
          await write([...(Array.isArray(previous) ? previous : []), entry].slice(-100));
        });
        return pending;
      },
      async export() {
        await pending;
        return JSON.stringify(await read(), null, 2);
      }
    };
  }
  const reporter = createLocalReporter({
    read: async () => (await chrome.storage.local.get(KEY))[KEY] || [],
    write: async entries => {
      await chrome.storage.local.set({
        [KEY]: entries
      });
    }
  });
  const recordLocalError = error => reporter.record(error);

  const setCrashOptions = value => {
    ({
      ...value,
      video: false,
      technical: false
    });
  };
  class LocalErrorReporter {
    static async captureException(error) {
      try {
        await recordLocalError(error);
      } catch {}
    }
  }

  const origin = 'https://www.youtube.com';
  const extensionId = 'crossz-youtube-extension';
  const isSameWindowMessage = event => event.source === window && event.origin === origin;

  class InjectedScript {
    constructor() {
      this.globalListener = void 0;
      this.listeners = [];
      this.addMessageListener = (type, handler) => {
        if (!this.globalListener) {
          this.globalListener = wrapErrorHandler(function injectedScriptMessageListenerGlobal(event) {
            if (!event.detail || typeof event.detail !== 'string') return;
            const detail = JSON.parse(event.detail);
            if (!isSameWindowMessage || (detail === null || detail === void 0 ? void 0 : detail.injectedScript) !== extensionId || !(detail !== null && detail !== void 0 && detail.type)) return;
            for (const listener of this.listeners) {
              listener(detail);
            }
          }.bind(this), true);
          document.addEventListener('crossz-message', this.globalListener);
        }
        const listener = wrapErrorHandler(function injectedScriptMessageListener(detail) {
          if (detail.type !== type) return;
          handler(detail === null || detail === void 0 ? void 0 : detail.message);
        }.bind(this), true);
        this.listeners.push(listener);
        return listener;
      };
      this.removeMessageListener = listener => {
        const index = this.listeners.indexOf(listener);
        if (index !== -1) {
          this.listeners.splice(index, 1);
        }
        if (this.globalListener && this.listeners.length === 0) {
          document.removeEventListener('crossz-message', this.globalListener);
          this.globalListener = undefined;
        }
      };
      this.receiveMessage = (type, timeout = 3000) => new Promise(function receiveMessagePromise(resolve, reject) {
        try {
          const receivedMessage = function reveicedMessage(message) {
            clearTimeout(timeoutId);
            injectedScript.removeMessageListener(changedListener);
            resolve(message);
          }.bind(this);
          const receiveMessageTimeout = function receiveMessageTimeout() {
            console.warn(`Never received a response message for "${type}" after ${timeout}ms`);
            receivedMessage();
          }.bind(this);
          const timeoutId = setTimeout(receiveMessageTimeout, timeout);
          const changedListener = injectedScript.addMessageListener(type, receivedMessage);
        } catch (ex) {
          reject(ex);
        }
      });
      this.postAndReceiveMessage = async (type, message, timeout) => {
        const receiveMessagePromise = this.receiveMessage(type, timeout);
        this.postMessage(type, message);
        return await receiveMessagePromise;
      };
    }
    postMessage(type, message) {
      const event = new CustomEvent('crossz-message', {
        detail: JSON.stringify({
          type,
          message,
          contentScript: extensionId
        })
      });
      return document.dispatchEvent(event);
    }
  }
  const injectedScript = new InjectedScript();

  setErrorHandler(ex => LocalErrorReporter.captureException(ex));
  injectedScript.addMessageListener('error', injectedEx => {
    const ex = new Error(injectedEx.message);
    ex.name = injectedEx.name;
    ex.stack = injectedEx.stack;
    if (injectedEx.details) ex.details = injectedEx.details;
    LocalErrorReporter.captureException(ex);
  });
  const setResourceWarning = url => {
    setWarning(url ? `Failed to load a resource. Reload the webpage to try it again.
This can happen after you have updated the extension.

Or if this happens often, view the error in your browser's DevTools javascript console panel.
Tip: Look for errors about this url: ${url}` : `Failed to load the extension on this webpage because it has been updated, reloaded or uninstalled.
Reload the webpage to reload the extension.`);
  };
  const waitForHtmlElement = async () => {
    if (document.documentElement) return;
    const stack = new Error().stack;
    await new Promise((resolve, reject) => {
      try {
        const observer = new MutationObserver(wrapErrorHandler(function onHtmlElementMutation() {
          if (!document.documentElement) return;
          observer.disconnect();
          resolve();
        }.bind(window), true));
        observer.observe(document, {
          childList: true
        });
      } catch (ex) {
        appendErrorStack(stack, ex);
        reject(ex);
      }
    });
  };
  const waitForHeadElement = async () => {
    if (document.head) return;
    const stack = new Error().stack;
    await new Promise((resolve, reject) => {
      try {
        const observer = new MutationObserver(wrapErrorHandler(function onHeadElementMutation() {
          if (!document.head) return;
          observer.disconnect();
          resolve();
        }.bind(window), true));
        observer.observe(document.documentElement, {
          childList: true
        });
      } catch (ex) {
        appendErrorStack(stack, ex);
        reject(ex);
      }
    });
  };
  const captureResourceLoadingException = async (url, event) => {
    var _chrome, _chrome$runtime;
    if (!((_chrome = chrome) !== null && _chrome !== void 0 && (_chrome$runtime = _chrome.runtime) !== null && _chrome$runtime !== void 0 && _chrome$runtime.id)) {
      setResourceWarning();
      return;
    }
    let error;
    try {
      const stack = new Error().stack;
      await new Promise((resolve, reject) => {
        try {
          const req = new XMLHttpRequest();
          req.onreadystatechange = () => {
            try {
              if (req.readyState == XMLHttpRequest.DONE) {
                if (req.status !== 200) {
                  error = new Error(`Cannot load ${url} (Status: ${req.statusText} ${req.status})`);
                  appendErrorStack(stack, error);
                }
                resolve();
              }
            } catch (ex) {
              reject(ex);
            }
          };
          req.open('GET', url, true);
          req.send();
        } catch (ex) {
          appendErrorStack(stack, ex);
          reject(ex);
        }
      });
    } catch (ex) {
      error = ex;
    } finally {
      if (error) {
        error.details = event;
        LocalErrorReporter.captureException(error);
      }
      setResourceWarning(url);
    }
  };
  wrapErrorHandler(async function loadContentScript() {
    var _chrome2, _chrome2$runtime, _chrome3, _chrome3$runtime;
    const version = getVersion();
    let crashOptions = defaultCrashOptions;
    try {
      crashOptions = (await storage.get('crashOptions')) || defaultCrashOptions;
      setCrashOptions(crashOptions);
    } catch (ex) {
      LocalErrorReporter.captureException(ex);
    }
    storage.addListener(function storageListener(changes) {
      var _changes$crashOptions;
      if (!((_changes$crashOptions = changes.crashOptions) !== null && _changes$crashOptions !== void 0 && _changes$crashOptions.newValue)) return;
      const crashOptions = changes.crashOptions.newValue;
      setCrashOptions(crashOptions);
    });
    await waitForHtmlElement();
    await waitForHeadElement();
    if (!((_chrome2 = chrome) !== null && _chrome2 !== void 0 && (_chrome2$runtime = _chrome2.runtime) !== null && _chrome2$runtime !== void 0 && _chrome2$runtime.id)) {
      setResourceWarning();
      return;
    }
    const loaded = await new Promise(resolve => {
      let url;
      try {
        url = chrome.runtime.getURL('scripts/injected.js');
      } catch {
        setResourceWarning();
        resolve(false);
        return;
      }
      const script = document.createElement('script');
      script.src = url;
      script.async = true;
      script.setAttribute('data-crash-options', JSON.stringify(crashOptions));
      script.setAttribute('data-version', version);
      script.addEventListener('error', async function injectScriptOnError(event) {
        await captureResourceLoadingException(script.src, event);
        resolve(false);
      }.bind(this));
      script.addEventListener('load', function injectStyleOnLoad() {
        resolve(true);
      }.bind(this));
      document.head.appendChild(script);
    });
    if (!((_chrome3 = chrome) !== null && _chrome3 !== void 0 && (_chrome3$runtime = _chrome3.runtime) !== null && _chrome3$runtime !== void 0 && _chrome3$runtime.id)) {
      setResourceWarning();
      return;
    }
    if (!loaded) return;
    let scriptUrl;
    try {
      scriptUrl = chrome.runtime.getURL('scripts/content-main.js');
    } catch {
      setResourceWarning();
      return;
    }
    try {
      await import(scriptUrl);
    } catch (error) {
      await captureResourceLoadingException(scriptUrl, error);
    }
  })();

})();
