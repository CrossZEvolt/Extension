(function () {
  'use strict';

  
  let console;

  (function () {
    const preMessage = 'Ambient light for YouTube™ |';

    const enrich = (...args) => {
      if (args.length <= 0) return args;

      if (typeof args[0] === 'string') {
        const [firstArg, ...postArgs] = args;
        return [`${preMessage} ${firstArg}`, ...postArgs];
      }

      return [preMessage, ...args];
    };

    console = {
      log: (...args) => globalThis.console.log(...enrich(...args)),
      debug: (...args) => globalThis.console.debug(...enrich(...args)),
      warn: (...args) => globalThis.console.warn(...enrich(...args)),
      error: (...args) => globalThis.console.error(...enrich(...args)),
      dir: (...args) => globalThis.console.dir(...args),
    };
  })();


  const AD_FIELDS = ['playerAds', 'adPlacements', 'adSlots'];
  const PLAYER_PATHS = new Set(['/youtubei/v1/player', '/youtubei/v1/playlist', '/youtubei/v1/get_watch']);
  const SHORTS_PATHS = new Set(['/youtubei/v1/reel_watch_sequence', '/youtubei/v1/reel/reel_watch_sequence']);
  function inheritedDescriptor(target, property) {
    for (let owner = target; owner; owner = Object.getPrototypeOf(owner)) {
      const descriptor = Object.getOwnPropertyDescriptor(owner, property);
      if (descriptor) return {
        owner,
        descriptor
      };
    }
  }
  function pruneFields(value) {
    if (!value || typeof value !== 'object' || Array.isArray(value)) return false;
    let changed = false;
    for (const key of AD_FIELDS) {
      var _Object$getOwnPropert;
      if ((_Object$getOwnPropert = Object.getOwnPropertyDescriptor(value, key)) !== null && _Object$getOwnPropert !== void 0 && _Object$getOwnPropert.configurable) {
        delete value[key];
        changed = true;
      }
    }
    return changed;
  }
  function prunePlayer(value) {
    if (!value || typeof value !== 'object') return false;
    let changed = Array.isArray(value) ? false : pruneFields(value);
    for (const envelope of Array.isArray(value) ? value : [value]) {
      const nested = envelope === null || envelope === void 0 ? void 0 : envelope.playerResponse;
      if (nested && nested !== envelope) changed = pruneFields(nested) || changed;
    }
    return changed;
  }
  function pruneShorts(value) {
    let changed = false;
    for (const envelope of [value, value === null || value === void 0 ? void 0 : value.reelWatchSequenceResponse]) {
      const entries = envelope === null || envelope === void 0 ? void 0 : envelope.entries;
      if (!Array.isArray(entries)) continue;
      for (let index = entries.length - 1; index >= 0; index--) {
        var _entries$index, _entries$index$comman, _entries$index$comman2, _entries$index$comman3;
        if (((_entries$index = entries[index]) === null || _entries$index === void 0 ? void 0 : (_entries$index$comman = _entries$index.command) === null || _entries$index$comman === void 0 ? void 0 : (_entries$index$comman2 = _entries$index$comman.reelWatchEndpoint) === null || _entries$index$comman2 === void 0 ? void 0 : (_entries$index$comman3 = _entries$index$comman2.adClientParams) === null || _entries$index$comman3 === void 0 ? void 0 : _entries$index$comman3.isAd) === true) {
          entries.splice(index, 1);
          changed = true;
        }
      }
    }
    return changed;
  }
  function installPlayerAdFilter(scope = window, {
    initialEnabled = false
  } = {}) {
    var _inheritedDescriptor, _scope$Response, _inheritedDescriptor2, _scope$Response2;
    if (scope.location.origin !== 'https://www.youtube.com') return;
    const installed = Symbol.for('crossz.player-ad-filter');
    if (scope[installed]) return;
    Object.defineProperty(scope, installed, {
      value: true
    });
    let enabled = initialEnabled === true;
    const responseKind = url => {
      if (typeof url !== 'string' || url === '') return null;
      try {
        const parsed = new URL(url, scope.location.href);
        if (parsed.origin !== 'https://www.youtube.com') return null;
        if (parsed.pathname === '/playlist' && parsed.searchParams.has('list')) return 'player';
        return PLAYER_PATHS.has(parsed.pathname) ? 'player' : SHORTS_PATHS.has(parsed.pathname) ? 'shorts' : null;
      } catch {
        return null;
      }
    };
    const prune = (value, kind) => {
      const changed = prunePlayer(value);
      return kind === 'shorts' ? pruneShorts(value) || changed : changed;
    };
    const filterValue = (value, kind = 'player') => {
      if (enabled) try {
        prune(value, kind);
      } catch {}
      return value;
    };
    const filterText = (text, kind = 'player') => {
      if (!enabled || typeof text !== 'string') return text;
      try {
        var _text$match;
        const prefix = ((_text$match = text.match(/^\)\]\}'(?:\r?\n)?/)) === null || _text$match === void 0 ? void 0 : _text$match[0]) || '';
        const value = JSON.parse(text.slice(prefix.length));
        return prune(value, kind) ? prefix + JSON.stringify(value) : text;
      } catch {
        return text;
      }
    };
    for (const key of ['ytInitialPlayerResponse', 'playerResponse']) {
      const descriptor = Object.getOwnPropertyDescriptor(scope, key);
      if (descriptor && (!descriptor.configurable || descriptor.get || descriptor.set || descriptor.writable === false)) continue;
      let value = descriptor === null || descriptor === void 0 ? void 0 : descriptor.value;
      Object.defineProperty(scope, key, {
        configurable: true,
        enumerable: (descriptor === null || descriptor === void 0 ? void 0 : descriptor.enumerable) ?? true,
        get: () => filterValue(value),
        set: next => {
          value = filterValue(next);
        }
      });
    }
    const originalText = (_inheritedDescriptor = inheritedDescriptor((_scope$Response = scope.Response) === null || _scope$Response === void 0 ? void 0 : _scope$Response.prototype, 'text')) === null || _inheritedDescriptor === void 0 ? void 0 : _inheritedDescriptor.descriptor.value;
    const originalClone = (_inheritedDescriptor2 = inheritedDescriptor((_scope$Response2 = scope.Response) === null || _scope$Response2 === void 0 ? void 0 : _scope$Response2.prototype, 'clone')) === null || _inheritedDescriptor2 === void 0 ? void 0 : _inheritedDescriptor2.descriptor.value;
    const ResponseConstructor = scope.Response,
      HeadersConstructor = scope.Headers;
    if (typeof scope.fetch === 'function' && typeof originalText === 'function' && typeof originalClone === 'function' && typeof ResponseConstructor === 'function' && typeof HeadersConstructor === 'function') {
      const replacement = (original, text, headers) => {
        const bytes = new TextEncoder().encode(text),
          branches = new Set();
        let reader = null,
          failure = null;
        const finish = branch => {
          branches.delete(branch);
          if (branches.size === 0 && reader) void reader.cancel().catch(() => {});
        };
        const create = (branchHeaders = headers) => {
          const branch = {
            controller: null
          };
          const stream = new ReadableStream({
            start(controller) {
              branch.controller = controller;
              if (failure) controller.error(failure);else branches.add(branch);
            },
            async pull(controller) {
              await Promise.resolve();
              if (failure) {
                controller.error(failure);
                finish(branch);
                return;
              }
              if (!branches.has(branch)) return;
              controller.enqueue(bytes.slice());
              controller.close();
              finish(branch);
            },
            cancel() {
              finish(branch);
            }
          }, {
            highWaterMark: 0
          });
          const response = new ResponseConstructor(stream, {
            status: original.status,
            statusText: original.statusText,
            headers: branchHeaders
          });
          Object.defineProperties(response, {
            url: {
              value: original.url,
              configurable: true
            },
            type: {
              value: original.type,
              configurable: true
            },
            redirected: {
              value: original.redirected,
              configurable: true
            },
            clone: {
              configurable: true,
              writable: true,
              value: function () {
                var _this$body;
                if (this !== response) return Reflect.apply(originalClone, this, []);
                if (this.bodyUsed || (_this$body = this.body) !== null && _this$body !== void 0 && _this$body.locked) throw new TypeError('Response body is already used or locked.');
                return create(this.headers);
              }
            }
          });
          for (const method of ['json', 'text', 'arrayBuffer', 'blob', 'bytes']) {
            const consume = response[method];
            if (typeof consume !== 'function') continue;
            Object.defineProperty(response, method, {
              configurable: true,
              writable: true,
              value: function (...args) {
                var _this$body2;
                const unavailable = this === response && (this.bodyUsed || ((_this$body2 = this.body) === null || _this$body2 === void 0 ? void 0 : _this$body2.locked));
                const pending = Reflect.apply(consume, this, args);
                if (this !== response || unavailable) return pending;
                return pending.catch(error => {
                  throw failure || error;
                });
              }
            });
          }
          return response;
        };
        const response = create();
        reader = original.body.getReader();
        void reader.closed.then(() => {}, error => {
          failure = error;
          for (const branch of branches) branch.controller.error(error);
          branches.clear();
        }).finally(() => {
          reader.releaseLock();
          reader = null;
        });
        return response;
      };
      const transform = async response => {
        const kind = responseKind(response.url);
        if (!enabled || !kind || !response.ok) return response;
        try {
          const copy = Reflect.apply(originalClone, response, []);
          const text = await Reflect.apply(originalText, copy, []);
          const filtered = filterText(text, kind);
          if (filtered === text) return response;
          const headers = new HeadersConstructor(response.headers);
          headers.delete('content-length');
          headers.delete('content-encoding');
          return replacement(response, filtered, headers);
        } catch {
          return response;
        }
      };
      try {
        const descriptor = Object.getOwnPropertyDescriptor(scope, 'fetch');
        Object.defineProperty(scope, 'fetch', {
          configurable: true,
          writable: true,
          enumerable: true,
          ...descriptor,
          value: new Proxy(scope.fetch, {
            apply: (target, receiver, args) => Reflect.apply(target, receiver, args).then(transform)
          })
        });
      } catch {}
    }
    for (const method of ['json', 'text']) {
      var _scope$Response3;
      const prototype = (_scope$Response3 = scope.Response) === null || _scope$Response3 === void 0 ? void 0 : _scope$Response3.prototype;
      const {
        owner,
        descriptor
      } = inheritedDescriptor(prototype, method) || {};
      if (typeof (descriptor === null || descriptor === void 0 ? void 0 : descriptor.value) !== 'function') continue;
      const original = descriptor.value;
      try {
        Object.defineProperty(owner, method, {
          ...descriptor,
          value: function (...args) {
            const kind = responseKind(this.url);
            return Reflect.apply(original, this, args).then(value => kind && this.ok ? method === 'json' ? filterValue(value, kind) : filterText(value, kind) : value);
          }
        });
      } catch {}
    }
    const textCache = new WeakMap();
    for (const property of ['responseText', 'response']) {
      var _scope$XMLHttpRequest;
      const prototype = (_scope$XMLHttpRequest = scope.XMLHttpRequest) === null || _scope$XMLHttpRequest === void 0 ? void 0 : _scope$XMLHttpRequest.prototype;
      const {
        descriptor
      } = inheritedDescriptor(prototype, property) || {};
      if (typeof (descriptor === null || descriptor === void 0 ? void 0 : descriptor.get) !== 'function') continue;
      const original = descriptor.get;
      try {
        Object.defineProperty(prototype, property, {
          ...descriptor,
          get: function () {
            const value = Reflect.apply(original, this, []);
            const kind = responseKind(this.responseURL);
            if (!enabled || this.readyState !== 4 || this.status < 200 || this.status >= 300 || !kind) return value;
            if (property === 'response' && this.responseType === 'json') return filterValue(value, kind);
            if (typeof value !== 'string' || !['', 'text'].includes(this.responseType)) return value;
            const cached = textCache.get(this);
            if ((cached === null || cached === void 0 ? void 0 : cached.original) === value) return cached.filtered;
            const filtered = filterText(value, kind);
            textCache.set(this, {
              original: value,
              filtered
            });
            return filtered;
          }
        });
      } catch {}
    }
    scope.document.addEventListener('crossz-ads-state', event => {
      if (typeof event.detail !== 'boolean') return;
      enabled = event.detail;
      if (enabled) for (const key of ['ytInitialPlayerResponse', 'playerResponse']) {
        try {
          filterValue(scope[key]);
        } catch {}
      }
    });
    scope.document.dispatchEvent(new scope.Event('crossz-ads-ready'));
  }

  installPlayerAdFilter(window, {
    initialEnabled: true
  });

})();
