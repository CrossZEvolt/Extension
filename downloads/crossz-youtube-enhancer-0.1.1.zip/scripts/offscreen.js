(function () {
  'use strict';

  
  let console;

  (function () {
    const preMessage = 'Ambient light for YouTube™ |';

    const enrich = (...args) => {
      if (args.length <= 0) return args;

      if (typeof args[0] === 'string') {
        const [firstArg, ...postArgs] = args;
        return [`${preMessage} ${firstArg}`, ...postArgs];
      }

      return [preMessage, ...args];
    };

    console = {
      log: (...args) => globalThis.console.log(...enrich(...args)),
      debug: (...args) => globalThis.console.debug(...enrich(...args)),
      warn: (...args) => globalThis.console.warn(...enrich(...args)),
      error: (...args) => globalThis.console.error(...enrich(...args)),
      dir: (...args) => globalThis.console.dir(...args),
    };
  })();


  const inactiveAudio = () => ({
    state: 'inactive',
    percent: 100
  });
  function validatePercent(value) {
    if (!Number.isInteger(value) || value < 100 || value > 500) throw new Error('Âm lượng phải là số nguyên từ 100% đến 500%.');
    return value;
  }

  function createAudioGraph({
    context,
    source,
    percent
  }) {
    validatePercent(percent);
    const gain = context.createGain(),
      compressor = context.createDynamicsCompressor();
    gain.gain.value = percent / 100;
    Object.entries({
      threshold: -3,
      knee: 0,
      ratio: 20,
      attack: 0.003,
      release: 0.1
    }).forEach(([key, value]) => {
      compressor[key].value = value;
    });
    source.connect(gain);
    gain.connect(compressor);
    compressor.connect(context.destination);
    return {
      setPercent(next) {
        validatePercent(next);
        const now = context.currentTime;
        gain.gain.cancelScheduledValues(now);
        gain.gain.setValueAtTime(gain.gain.value, now);
        gain.gain.linearRampToValueAtTime(next / 100, now + 0.02);
      },
      dispose() {
        source.disconnect();
        gain.disconnect();
        compressor.disconnect();
      }
    };
  }

  function createSessionManager({
    getStream,
    createContext
  }) {
    const entries = new Map();
    async function release(entry) {
      try {
        var _entry$graph;
        (_entry$graph = entry.graph) === null || _entry$graph === void 0 ? void 0 : _entry$graph.dispose();
      } catch {}
      for (const track of ((_entry$stream = entry.stream) === null || _entry$stream === void 0 ? void 0 : _entry$stream.getTracks()) || []) {
        var _entry$stream;
        track.stop();
      }
      try {
        var _entry$context;
        await ((_entry$context = entry.context) === null || _entry$context === void 0 ? void 0 : _entry$context.close());
      } catch {}
    }
    async function stop(tabId) {
      const entry = entries.get(tabId);
      entries.delete(tabId);
      if (entry) await release(entry);
      return inactiveAudio();
    }
    async function setPercent(tabId, percent) {
      var _entry, _entry2;
      validatePercent(percent);
      if (percent === 100) return stop(tabId);
      let entry = entries.get(tabId);
      if (((_entry = entry) === null || _entry === void 0 ? void 0 : _entry.state) === 'starting') await entry.ready;
      entry = entries.get(tabId);
      if (!((_entry2 = entry) !== null && _entry2 !== void 0 && _entry2.graph)) throw new Error('Tab chưa bật khuếch đại.');
      entry.graph.setPercent(percent);
      entry.percent = percent;
      return {
        state: entry.state,
        percent
      };
    }
    function start(tabId, streamId, percent) {
      validatePercent(percent);
      if (entries.has(tabId)) return setPercent(tabId, percent);
      const entry = {
        state: 'starting',
        percent
      };
      entries.set(tabId, entry);
      entry.ready = (async () => {
        try {
          entry.stream = await getStream(streamId);
          if (entries.get(tabId) !== entry) {
            await release(entry);
            return inactiveAudio();
          }
          entry.context = createContext();
          const source = entry.context.createMediaStreamSource(entry.stream);
          entry.graph = createAudioGraph({
            context: entry.context,
            source,
            percent
          });
          if (entry.context.state === 'suspended') await entry.context.resume();
          if (entries.get(tabId) !== entry) {
            await release(entry);
            return inactiveAudio();
          }
          for (const track of entry.stream.getTracks()) track.addEventListener('ended', () => {
            if (entries.get(tabId) === entry) void stop(tabId);
          }, {
            once: true
          });
          entry.state = 'active';
          return {
            state: 'active',
            percent
          };
        } catch (error) {
          if (entries.get(tabId) === entry) entries.delete(tabId);
          await release(entry);
          throw error;
        }
      })();
      return entry.ready;
    }
    return {
      start,
      setPercent,
      stop,
      snapshot: () => Object.fromEntries([...entries].map(([id, e]) => [id, {
        state: e.state,
        percent: e.percent
      }]))
    };
  }

  const sessions = createSessionManager({
    getStream: streamId => navigator.mediaDevices.getUserMedia({
      audio: {
        mandatory: {
          chromeMediaSource: 'tab',
          chromeMediaSourceId: streamId
        }
      },
      video: false
    }),
    createContext: () => new AudioContext()
  });
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    if (sender.id !== chrome.runtime.id || (message === null || message === void 0 ? void 0 : message.channel) !== 'crossz-audio') return;
    const {
      type,
      tabId,
      streamId,
      percent
    } = message;
    const run = () => {
      if (type === 'STATUS') return sessions.snapshot();
      if (!Number.isInteger(tabId) || tabId < 0) throw new Error('Invalid tab');
      if (type === 'STOP') return sessions.stop(tabId);
      validatePercent(percent);
      if (type === 'SET') return sessions.setPercent(tabId, percent);
      if (type === 'START' && typeof streamId === 'string' && streamId.length > 0 && streamId.length < 10000) return sessions.start(tabId, streamId, percent);
      throw new Error('Invalid audio command');
    };
    Promise.resolve().then(run).then(data => reply({
      ok: true,
      data
    }), error => reply({
      ok: false,
      error: {
        code: 'AUDIO_ERROR',
        message: error.message
      }
    }));
    return true;
  });

})();
