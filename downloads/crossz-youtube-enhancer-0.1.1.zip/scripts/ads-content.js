(function () {
  'use strict';

  
  let console;

  (function () {
    const preMessage = 'Ambient light for YouTube™ |';

    const enrich = (...args) => {
      if (args.length <= 0) return args;

      if (typeof args[0] === 'string') {
        const [firstArg, ...postArgs] = args;
        return [`${preMessage} ${firstArg}`, ...postArgs];
      }

      return [preMessage, ...args];
    };

    console = {
      log: (...args) => globalThis.console.log(...enrich(...args)),
      debug: (...args) => globalThis.console.debug(...enrich(...args)),
      warn: (...args) => globalThis.console.warn(...enrich(...args)),
      error: (...args) => globalThis.console.error(...enrich(...args)),
      dir: (...args) => globalThis.console.dir(...args),
    };
  })();


  const AD_SLOTS = 'ytd-ad-slot-renderer,ytd-display-ad-renderer,ytd-promoted-sparkles-web-renderer,ytd-in-feed-ad-layout-renderer,ytd-rich-item-renderer:has(ytd-ad-slot-renderer),ytd-rich-item-renderer:has(ytd-in-feed-ad-layout-renderer),.video-ads .ytp-ad-overlay-container';
  const SKIP = '.ytp-ad-skip-button,.ytp-ad-skip-button-modern,.ytp-skip-ad-button';
  const AD_PLAYERS = '.html5-video-player.ad-showing,.html5-video-player.ad-interrupting';
  const OWNED = 'data-crossz-ad-hidden';
  function createAdController({
    document,
    requestFrame,
    cancelFrame
  }) {
    let observer = null,
      frame = null;
    const marked = new Set(),
      clicked = new Set();
    function available(button) {
      const style = document.defaultView.getComputedStyle(button);
      return !button.disabled && button.getAttribute('aria-disabled') !== 'true' && button.getClientRects().length > 0 && style.visibility !== 'hidden' && style.visibility !== 'collapse' && style.display !== 'none';
    }
    function scan() {
      frame = null;
      for (const element of document.querySelectorAll(AD_SLOTS)) {
        if (!element.hasAttribute(OWNED)) {
          element.setAttribute(OWNED, '');
          marked.add(element);
        }
      }
      const players = document.querySelectorAll(AD_PLAYERS);
      for (const button of clicked) {
        if (!button.isConnected || !button.closest(AD_PLAYERS) || !available(button)) clicked.delete(button);
      }
      for (const player of players) for (const button of player.querySelectorAll(SKIP)) {
        if (clicked.has(button) || !available(button)) continue;
        clicked.add(button);
        button.click();
      }
      for (const element of marked) {
        if (!element.isConnected || !element.matches(AD_SLOTS)) {
          element.removeAttribute(OWNED);
          marked.delete(element);
        }
      }
    }
    const schedule = () => {
      if (frame === null) frame = requestFrame(scan);
    };
    return {
      start() {
        if (observer) return;
        observer = new document.defaultView.MutationObserver(schedule);
        observer.observe(document, {
          childList: true,
          subtree: true,
          attributes: true,
          attributeFilter: ['class', 'style', 'hidden', 'disabled', 'aria-disabled']
        });
        document.addEventListener('yt-navigate-finish', schedule);
        schedule();
      },
      stop() {
        var _observer;
        (_observer = observer) === null || _observer === void 0 ? void 0 : _observer.disconnect();
        observer = null;
        document.removeEventListener('yt-navigate-finish', schedule);
        if (frame !== null) cancelFrame(frame);
        frame = null;
        for (const element of marked) element.removeAttribute(OWNED);
        marked.clear();
        clicked.clear();
      }
    };
  }

  const PREFERENCES_KEY = 'crossz-preferences-v1';
  const defaults = {
    schemaVersion: 1,
    adBlockingEnabled: true
  };
  function parseImportedPreferences(json) {
    const value = JSON.parse(json);
    if (!value || Array.isArray(value) || value.schemaVersion !== 1 || typeof value.adBlockingEnabled !== 'boolean' || Object.keys(value).some(k => !['schemaVersion', 'adBlockingEnabled'].includes(k))) throw new Error('Cấu hình CrossZ không hợp lệ.');
    return {
      schemaVersion: 1,
      adBlockingEnabled: value.adBlockingEnabled
    };
  }
  async function readPreferences(area = chrome.storage.local) {
    const value = (await area.get(PREFERENCES_KEY))[PREFERENCES_KEY];
    try {
      return value ? parseImportedPreferences(JSON.stringify(value)) : {
        ...defaults
      };
    } catch {
      return {
        ...defaults
      };
    }
  }

  function startAdContent({
    document,
    area = chrome.storage.local
  }) {
    const view = document.defaultView;
    const ads = createAdController({
      document,
      requestFrame: callback => view.requestAnimationFrame(callback),
      cancelFrame: id => view.cancelAnimationFrame(id)
    });
    let revision = 0,
      enabled,
      stopped = false;
    const publish = () => {
      if (!stopped && typeof enabled === 'boolean') document.dispatchEvent(new view.CustomEvent('crossz-ads-state', {
        detail: enabled
      }));
    };
    const apply = value => {
      if (stopped) return;
      enabled = value;
      if (enabled) ads.start();else ads.stop();
      publish();
    };
    const onChanged = changes => {
      if (!Object.hasOwn(changes, PREFERENCES_KEY)) return;
      revision++;
      let value = true;
      const next = changes[PREFERENCES_KEY].newValue;
      if (next !== undefined) {
        try {
          value = parseImportedPreferences(JSON.stringify(next)).adBlockingEnabled;
        } catch {}
      }
      apply(value);
    };
    area.onChanged.addListener(onChanged);
    document.addEventListener('crossz-ads-ready', publish);
    const initialRevision = revision;
    const ready = readPreferences(area).then(preferences => {
      if (revision === initialRevision) apply(preferences.adBlockingEnabled);
    }).catch(() => {});
    return {
      ready,
      stop() {
        stopped = true;
        area.onChanged.removeListener(onChanged);
        document.removeEventListener('crossz-ads-ready', publish);
        ads.stop();
      }
    };
  }

  startAdContent({
    document
  });

})();
