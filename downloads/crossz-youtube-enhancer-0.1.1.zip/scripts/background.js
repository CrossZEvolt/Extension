(function () {
  'use strict';

  
  let console;

  (function () {
    const preMessage = 'Ambient light for YouTube™ |';

    const enrich = (...args) => {
      if (args.length <= 0) return args;

      if (typeof args[0] === 'string') {
        const [firstArg, ...postArgs] = args;
        return [`${preMessage} ${firstArg}`, ...postArgs];
      }

      return [preMessage, ...args];
    };

    console = {
      log: (...args) => globalThis.console.log(...enrich(...args)),
      debug: (...args) => globalThis.console.debug(...enrich(...args)),
      warn: (...args) => globalThis.console.warn(...enrich(...args)),
      error: (...args) => globalThis.console.error(...enrich(...args)),
      dir: (...args) => globalThis.console.dir(...args),
    };
  })();


  const PREFERENCES_KEY = 'crossz-preferences-v1';
  const defaults = {
    schemaVersion: 1,
    adBlockingEnabled: true
  };
  function parseImportedPreferences(json) {
    const value = JSON.parse(json);
    if (!value || Array.isArray(value) || value.schemaVersion !== 1 || typeof value.adBlockingEnabled !== 'boolean' || Object.keys(value).some(k => !['schemaVersion', 'adBlockingEnabled'].includes(k))) throw new Error('Cấu hình CrossZ không hợp lệ.');
    return {
      schemaVersion: 1,
      adBlockingEnabled: value.adBlockingEnabled
    };
  }
  async function readPreferences(area = chrome.storage.local) {
    const value = (await area.get(PREFERENCES_KEY))[PREFERENCES_KEY];
    try {
      return value ? parseImportedPreferences(JSON.stringify(value)) : {
        ...defaults
      };
    } catch {
      return {
        ...defaults
      };
    }
  }
  async function writePreferences(value, area = chrome.storage.local) {
    await area.set({
      [PREFERENCES_KEY]: parseImportedPreferences(JSON.stringify(value))
    });
  }

  async function setAdRulesEnabled(enabled, api = chrome) {
    if (typeof enabled !== 'boolean') throw new Error('Invalid ad setting');
    await api.declarativeNetRequest.updateEnabledRulesets({
      enableRulesetIds: enabled ? ['youtube_ads'] : [],
      disableRulesetIds: enabled ? [] : ['youtube_ads']
    });
  }
  function createAdSettingController(api = chrome) {
    let pending = Promise.resolve();
    const enqueue = action => {
      const operation = pending.catch(() => {}).then(action);
      pending = operation;
      return operation;
    };
    const setEnabled = enabled => enqueue(async () => {
      const previous = await readPreferences(api.storage.local);
      await setAdRulesEnabled(enabled, api);
      try {
        await writePreferences({
          ...previous,
          adBlockingEnabled: enabled
        }, api.storage.local);
      } catch (error) {
        await setAdRulesEnabled(previous.adBlockingEnabled, api);
        throw error;
      }
    });
    setEnabled.reconcile = () => enqueue(async () => {
      const preferences = await readPreferences(api.storage.local);
      await setAdRulesEnabled(preferences.adBlockingEnabled, api);
    });
    return setEnabled;
  }

  const inactiveAudio = () => ({
    state: 'inactive',
    percent: 100
  });
  const isYouTube = url => {
    try {
      return new URL(url).origin === 'https://www.youtube.com';
    } catch {
      return false;
    }
  };
  function validatePercent(value) {
    if (!Number.isInteger(value) || value < 100 || value > 500) throw new Error('Âm lượng phải là số nguyên từ 100% đến 500%.');
    return value;
  }
  function parsePopupCommand(message, sender, extensionOrigin) {
    try {
      const root = new URL(extensionOrigin),
        url = new URL(sender.url);
      if (sender.id !== root.host || url.protocol !== root.protocol || url.host !== root.host || url.pathname !== '/popup.html') return null;
      if (!message || message.channel !== 'crossz-worker') return null;
      const {
        type,
        tabId = null,
        payload = {}
      } = message;
      if (tabId !== null && (!Number.isInteger(tabId) || tabId < 0)) return null;
      if (['GET_SNAPSHOT', 'AMBIENT_OPEN_SETTINGS', 'AUDIO_STOP'].includes(type)) return {
        type,
        tabId
      };
      if (['AMBIENT_SET_ENABLED', 'AD_SET_ENABLED'].includes(type) && typeof payload.enabled === 'boolean') return {
        type,
        tabId,
        enabled: payload.enabled
      };
      if (type === 'AUDIO_SET_GAIN' && tabId !== null) return {
        type,
        tabId,
        percent: validatePercent(payload.percent)
      };
    } catch {
      return null;
    }
    return null;
  }
  function parseOptionsCommand(message, sender, extensionOrigin) {
    try {
      var _message$payload;
      const root = new URL(extensionOrigin),
        url = new URL(sender.url);
      if (sender.id !== root.host || url.protocol !== root.protocol || url.host !== root.host || url.pathname !== '/options.html') return null;
      if ((message === null || message === void 0 ? void 0 : message.channel) !== 'crossz-worker' || message.type !== 'AD_SET_ENABLED' || typeof ((_message$payload = message.payload) === null || _message$payload === void 0 ? void 0 : _message$payload.enabled) !== 'boolean') return null;
      return {
        type: 'AD_SET_ENABLED',
        tabId: null,
        enabled: message.payload.enabled
      };
    } catch {
      return null;
    }
  }

  function installWorker(api = chrome, {
    audio = null,
    setAdEnabled = null
  } = {}) {
    const getTab = async tabId => {
      try {
        return tabId === null ? null : await api.tabs.get(tabId);
      } catch {
        return null;
      }
    };
    const getSnapshot = async tabId => {
      const [tab, prefs, stored] = await Promise.all([getTab(tabId), readPreferences(api.storage.local), api.storage.local.get('setting-enabled')]);
      return {
        tabId,
        isYouTube: isYouTube(tab === null || tab === void 0 ? void 0 : tab.url),
        ambientEnabled: stored['setting-enabled'] ?? true,
        adBlockingEnabled: prefs.adBlockingEnabled,
        audio: audio ? await audio.snapshot(tabId) : inactiveAudio()
      };
    };
    async function handle(command) {
      const {
        type,
        tabId
      } = command;
      if (type === 'GET_SNAPSHOT') return getSnapshot(tabId);
      if (type === 'AMBIENT_SET_ENABLED') {
        await api.storage.local.set({
          'setting-enabled': command.enabled
        });
      } else if (type === 'AD_SET_ENABLED') {
        if (!setAdEnabled) throw new Error('NOT_AVAILABLE');
        await setAdEnabled(command.enabled);
      } else {
        const tab = await getTab(tabId);
        if (!isYouTube(tab === null || tab === void 0 ? void 0 : tab.url)) throw new Error('Hãy mở tab YouTube để sử dụng chức năng này.');
        if (type === 'AMBIENT_OPEN_SETTINGS') {
          var _reply$error, _reply$error2;
          const reply = await api.tabs.sendMessage(tabId, {
            channel: 'crossz-content',
            type
          }, {
            frameId: 0
          });
          if (!(reply !== null && reply !== void 0 && reply.ok)) throw Object.assign(new Error((reply === null || reply === void 0 ? void 0 : (_reply$error = reply.error) === null || _reply$error === void 0 ? void 0 : _reply$error.message) || 'Video chưa sẵn sàng.'), {
            code: (reply === null || reply === void 0 ? void 0 : (_reply$error2 = reply.error) === null || _reply$error2 === void 0 ? void 0 : _reply$error2.code) || 'PLAYER_NOT_READY'
          });
        } else if (type === 'AUDIO_SET_GAIN' && audio) await audio.setGain(tabId, command.percent);else if (type === 'AUDIO_STOP' && audio) await audio.stop(tabId);else throw new Error('NOT_AVAILABLE');
      }
      return getSnapshot(tabId);
    }
    api.runtime.onMessage.addListener((message, sender, reply) => {
      if ((message === null || message === void 0 ? void 0 : message.channel) !== 'crossz-worker') return;
      const command = parsePopupCommand(message, sender, api.runtime.getURL('')) || parseOptionsCommand(message, sender, api.runtime.getURL(''));
      if (!command) {
        reply({
          ok: false,
          error: {
            code: 'INVALID_COMMAND',
            message: 'Yêu cầu không hợp lệ.'
          }
        });
        return;
      }
      handle(command).then(data => reply({
        ok: true,
        data
      }), error => reply({
        ok: false,
        error: {
          code: error.code || 'COMMAND_FAILED',
          message: error.message
        }
      }));
      return true;
    });
    return {
      getSnapshot
    };
  }

  function createAudioCoordinator(api = chrome) {
    let lifecycle = Promise.resolve();
    const starts = new Map(),
      generations = new Map();
    const contexts = () => api.runtime.getContexts({
      contextTypes: ['OFFSCREEN_DOCUMENT'],
      documentUrls: [api.runtime.getURL('offscreen.html')]
    });
    const serial = action => {
      lifecycle = lifecycle.catch(() => {}).then(action);
      return lifecycle;
    };
    const send = async (type, payload = {}) => {
      var _reply$error;
      const reply = await api.runtime.sendMessage({
        channel: 'crossz-audio',
        type,
        ...payload
      });
      if (!(reply !== null && reply !== void 0 && reply.ok)) throw new Error((reply === null || reply === void 0 ? void 0 : (_reply$error = reply.error) === null || _reply$error === void 0 ? void 0 : _reply$error.message) || 'Không kết nối được bộ xử lý âm thanh.');
      return reply.data;
    };
    const status = async () => (await contexts()).length ? await send('STATUS') : {};
    const ensure = () => serial(async () => {
      if (!(await contexts()).length) await api.offscreen.createDocument({
        url: 'offscreen.html',
        reasons: ['USER_MEDIA'],
        justification: 'Process user-activated YouTube tab audio locally.'
      });
    });
    const closeIfIdle = () => serial(async () => {
      if (starts.size || !(await contexts()).length) return;
      const states = await send('STATUS');
      if (!starts.size && !Object.keys(states).length) await api.offscreen.closeDocument();
    });
    async function stop(tabId) {
      generations.set(tabId, (generations.get(tabId) || 0) + 1);
      if ((await contexts()).length) await send('STOP', {
        tabId
      });
      await closeIfIdle();
      return inactiveAudio();
    }
    async function setGain(tabId, percent) {
      validatePercent(percent);
      if (percent === 100) return stop(tabId);
      const generation = generations.get(tabId) || 0;
      if (starts.has(tabId)) {
        await starts.get(tabId);
        return generation === (generations.get(tabId) || 0) ? setGain(tabId, percent) : inactiveAudio();
      }
      const operation = (async () => {
        const tab = await api.tabs.get(tabId);
        if (!isYouTube(tab.url)) throw new Error('Chỉ bật khuếch đại trên tab YouTube.');
        const states = await status();
        if (generation !== (generations.get(tabId) || 0)) return inactiveAudio();
        if (states[tabId]) return send('SET', {
          tabId,
          percent
        });
        await ensure();
        if (generation !== (generations.get(tabId) || 0)) return inactiveAudio();
        const streamId = await api.tabCapture.getMediaStreamId({
          targetTabId: tabId
        });
        if (generation !== (generations.get(tabId) || 0)) return inactiveAudio();
        return send('START', {
          tabId,
          streamId,
          percent
        });
      })();
      starts.set(tabId, operation);
      try {
        return await operation;
      } finally {
        if (starts.get(tabId) === operation) starts.delete(tabId);
        await closeIfIdle().catch(() => {});
      }
    }
    return {
      setGain,
      stop,
      snapshot: async tabId => (await status())[tabId] || inactiveAudio(),
      closeIfIdle
    };
  }

  const audio = createAudioCoordinator();
  const setAdEnabled = createAdSettingController();
  setAdEnabled.reconcile().catch(() => {});
  installWorker(chrome, {
    audio,
    setAdEnabled
  });
  chrome.tabs.onRemoved.addListener(tabId => {
    audio.stop(tabId).catch(() => {});
  });
  chrome.tabs.onUpdated.addListener(async (tabId, changes) => {
    if (!changes.url && changes.status !== 'loading') return;
    try {
      const tab = await chrome.tabs.get(tabId);
      if (!tab.url || new URL(tab.url).origin !== 'https://www.youtube.com') await audio.stop(tabId);
    } catch {
      await audio.stop(tabId).catch(() => {});
    }
  });
  chrome.tabCapture.onStatusChanged.addListener(info => {
    if (['stopped', 'error'].includes(info.status)) audio.stop(info.tabId).catch(() => {});
  });

})();
